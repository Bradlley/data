package com.aispeech.aios.bridge.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.R;
import com.aispeech.aios.bridge.listener.BridgeMusicControlListener;
import com.aispeech.aios.common.bean.MediaKey;
import com.aispeech.aios.sdk.AIOSForCarSDK;
import com.aispeech.aios.sdk.bean.LocalMusic;
import com.aispeech.aios.sdk.bean.ThirdMusicInfo;
import com.aispeech.aios.sdk.manager.AIOSMusicManager;
import com.aispeech.aios.sdk.manager.AIOSMusicManager.OnLocalSearchedListener;
import com.aispeech.aios.sdk.manager.AIOSMusicManager.OnSyncFinishedListener;
import java.util.ArrayList;
import java.util.List;

/**
 * 音乐功能Demo，主要是AIOSMusicListener接口类，可以在音乐app中实现
 */
public class MusicActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "MusicActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        AIOSMusicManager.getInstance().setLocalMusicInfo("AIOS音乐", AIOSForCarSDK.getPackageName());
//        AIOSMusicManager.getInstance().setDefaultMusic(AIOSForCarSDK.getPackageName());
        AIOSMusicManager.getInstance().setStrategyEnable(true);

        AIOSMusicManager.getInstance().setOnControlListener(new BridgeMusicControlListener());
        AIOSMusicManager.getInstance().setOnSearchListener(new AIOSMusicManager.OnSearchListener() {
            @Override
            public void onSearch(String packageName, MediaKey mediaKey) {
                String artist = mediaKey.getArtist();
                String title = mediaKey.getTitle();
                String album = mediaKey.getAlbum();
                String style = mediaKey.getStyle();
                String type = mediaKey.getType();
                AILog.d(TAG, "正在为你搜歌：" + artist + title + album + style + type);

                //模拟搜索结果，正式项目中请注意该方法由主线程调用，不要做耗时操作
                List<ThirdMusicInfo> thirdMusicInfoList = new ArrayList<>();
                thirdMusicInfoList.add(new ThirdMusicInfo("0001", "七里香", "周杰伦"));
                thirdMusicInfoList.add(new ThirdMusicInfo("0002", "借口", "周杰伦", "七里香", 111, 56231, "/card/music/02.mp3", "借口-周杰伦"));
                //localName属性只针对本地音乐，如果在线音乐设置该属性，会直接被清空
                thirdMusicInfoList.add(new ThirdMusicInfo("0003", "搁浅", "周杰伦", "七里香", 127, 56231, "http://music.163.com/card/music/03.mp3", "无效的localName"));
                thirdMusicInfoList.add(new ThirdMusicInfo("0004", "半岛铁盒", "周杰伦", "七里香", 129, 56231, "http://music.163.com/card/music/04.mp3"));
                thirdMusicInfoList.add(new ThirdMusicInfo("0005", "暗号", "周杰伦", "七里香", 100, 56231, "/card/music/05.mp3"));
                thirdMusicInfoList.add(new ThirdMusicInfo("0006", "回到过去", "周杰伦", "七里香", 201, 56231, "http://music.163.com/card/music/06.mp3"));
                //将模拟的搜索结果发给AIOS
                AIOSMusicManager.getInstance().postMusicSearchResult(thirdMusicInfoList);
            }
        }, AIOSForCarSDK.getPackageName());
        AIOSMusicManager.getInstance().setOnSyncFinishedListener(new OnSyncFinishedListener() {
            @Override
            public String onSyncFinished(boolean isSuccess) {
                if (isSuccess) {
                    return "本地音乐同步完成";
                } else {
                    return "本地音乐同步失败";
                }
            }
        });
        AIOSMusicManager.getInstance().setOnLocalSearchedListener(new OnLocalSearchedListener() {
            @Override
            public void onLocalSearched(List<ThirdMusicInfo> list) {
                AILog.d(TAG, "找到音乐 ： " + list.size());
                for (int i = 0; i < list.size(); i++) {
                    AILog.d(TAG, list.get(i).getUrl());
                }

                AIOSMusicManager.getInstance().postMusicSearchResult(list);
            }
        }, AIOSForCarSDK.getPackageName());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_sync_musics:
                List<LocalMusic> localMusics = new ArrayList<LocalMusic>();

                LocalMusic localMusic = new LocalMusic();
                localMusic.setTitle("南山南");  //歌曲名
                localMusic.setArtist("马頔"); //歌手名
                localMusic.setName("南山南-马頔");  //文件名
                localMusics.add(localMusic);
                localMusics.add(new LocalMusic("皆非", "马頔", "皆非-马頔"));

                AIOSMusicManager.getInstance().syncLocalMusicList(localMusics);
                break;
            case R.id.button_scan_enable:
                //只是Demo作为演示，代码中在初始化时调用一次即可
                AIOSMusicManager.getInstance().setScanLocalMusicEnabled(true);
                break;

            case R.id.button_scan_disable:
                //只是Demo作为演示，代码中在初始化时调用一次即可
                AIOSMusicManager.getInstance().setScanLocalMusicEnabled(false);
                break;

            case R.id.button_display_list_enable:
                //设置纯搜歌名时，显示结果列表
                AIOSMusicManager.getInstance().setDisplayListEnabled(true);
                break;
            case R.id.button_display_list_disable:
                //设置纯搜歌名时，不显示结果列表
                AIOSMusicManager.getInstance().setDisplayListEnabled(false);
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //清除音乐应用信息
        AIOSMusicManager.getInstance().cleanLocalMusicInfo();
        //注销音乐监听器
        AIOSMusicManager.getInstance().unregisterMusicListener();
        AIOSMusicManager.getInstance().setDefaultMusic(null);
    }
}
