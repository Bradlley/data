package com.aispeech.aios.bridge.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.BridgeApplication;
import com.aispeech.aios.bridge.R;
import com.aispeech.aios.bridge.utils.PreferenceUtil;
import com.aispeech.aios.common.bean.CustomizeTTSData;
import com.aispeech.aios.common.bean.MajorWakeup;
import com.aispeech.aios.sdk.AIOSForCarSDK;
import com.aispeech.aios.sdk.bean.Command;
import com.aispeech.aios.sdk.bean.ShortcutWakeup;
import com.aispeech.aios.sdk.listener.AIOSCustomizeListener;
import com.aispeech.aios.sdk.manager.AIOSCustomizeManager;
import com.aispeech.aios.sdk.manager.AIOSTTSManager;

import java.util.ArrayList;
import java.util.List;

/**
 * 自定义命令示例类
 */
public class CustomizeActivity extends Activity {

    private static final String TAG = "CustomizeActivity";
    private static final String OPEN_AIR_CONDITION = "/condition/open";
    private static final String OPEN_DOOR = "da kai che men";
    private static final String CLOSE_DOOR = "guan bi che men";

    private static long timestamp = 0;
    private CheckBox aecSwitch;
    private CheckBox interruptSwitch;
    private CheckBox aiosSwitch;
    private CheckBox nativeShortcutSwitch;
    private CheckBox oneshotSwitchCB;
    private SeekBar rateSeekBar;

    private EditText seek_thresh_percent_value_tv;
    private Button seek_thresh_percent_value_btn;
    private SeekBar seek_thresh_percent;

    /**
     * 自定义命令监听器
     **/
    private AIOSCustomizeListener customizeListener = new AIOSCustomizeListener() {

        /**
         * 执行注册的自定义命令时调用
         * @param command 自定义命令
         */
        @Override
        public void onCommandEffect(@NonNull String command) {
            if (OPEN_AIR_CONDITION.equals(command)) {
                AIOSTTSManager.speak("为您打开空调");
            }
            AILog.i(TAG, "Command effect: " + command);
        }

        /**
         * 当识别到定制的快捷唤醒词时执行
         *
         * @param pinyin 识别的快捷唤醒拼音
         */
        @Override
        public void onShortcutWakeUp(@NonNull String pinyin) {
            if (OPEN_DOOR.equals(pinyin)) {
                AIOSTTSManager.speak("车门已打开");
            } else if (CLOSE_DOOR.endsWith(pinyin)) {
                AIOSTTSManager.speak("车门已关闭");
            }
            AILog.i(TAG, "Short cut wakeup:" + pinyin);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize);
        //注册自定义命令监听器，以便在自定义的命令生效时作自己的处理
        AIOSCustomizeManager.getInstance().registerCustomizeListener(customizeListener);

        //清空AIOS保存的自定义命令缓存，请根据具体情况决定是否调用
        AIOSCustomizeManager.getInstance().cleanCommands();

        aiosSwitch = (CheckBox) findViewById(R.id.switch_aios);
        aecSwitch = (CheckBox) findViewById(R.id.switch_aec);
        interruptSwitch = (CheckBox) findViewById(R.id.switch_interrupt);
        nativeShortcutSwitch = (CheckBox) findViewById(R.id.switch_native_shortcut);
        oneshotSwitchCB = (CheckBox) findViewById(R.id.switch_oneshot_cb);
        rateSeekBar = (SeekBar) findViewById(R.id.seek_speech_rate);
        seek_thresh_percent_value_tv = (EditText) findViewById(R.id.seek_thresh_percent_value_tv);
        seek_thresh_percent_value_btn = (Button) findViewById(R.id.seek_thresh_percent_value_btn);
        seek_thresh_percent = (SeekBar) findViewById(R.id.seek_thresh_percent);

        aecSwitch.setChecked(PreferenceUtil.getBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_AEC_ENABLED, false));
        interruptSwitch.setChecked(PreferenceUtil.getBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_INTERRUPT_ENABLED, false));
        nativeShortcutSwitch.setChecked(PreferenceUtil.getBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_NATIVE_SHORTCUT_ENABLE, true));
        oneshotSwitchCB.setChecked(PreferenceUtil.getBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_ONESHOT_SWITCH, false));

        aiosSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //是否启用AIOS
                PreferenceUtil.setBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_AIOS_SWITCH, isChecked);
                if (isChecked) {
                    //off -> on
                    AIOSForCarSDK.enableAIOS();
                } else {
                    //on -> off
                    AIOSForCarSDK.disableAIOS();
                }
            }
        });
        aecSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                PreferenceUtil.setBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_AEC_ENABLED, isChecked);
                AIOSCustomizeManager.getInstance().setAECEnabled(isChecked);
            }
        });
        interruptSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //是否开启打断
                PreferenceUtil.setBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_INTERRUPT_ENABLED, isChecked);
                AIOSCustomizeManager.getInstance().setInterruptEnabled(isChecked);
            }
        });

        nativeShortcutSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //是否使用AIOS原生的快捷唤醒词
                PreferenceUtil.setBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_NATIVE_SHORTCUT_ENABLE, isChecked);
                AIOSCustomizeManager.getInstance().setNativeShortcutWakeupsEnabled(isChecked);
            }
        });

        oneshotSwitchCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //是否开启oneshot模式
                PreferenceUtil.setBoolean(BridgeApplication.getContext(), PreferenceUtil.IS_ONESHOT_SWITCH, isChecked);
                AIOSCustomizeManager.getInstance().setOneshotEnabled(isChecked);
            }
        });

        rateSeekBar.setMax(20);
        rateSeekBar.setProgress(10);
        rateSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Toast.makeText(CustomizeActivity.this, "语速调到：" + seekBar.getProgress() * 10 + "%", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int rate = seekBar.getProgress();
                if (rate >= 5 && rate <= 20) {
                    AIOSCustomizeManager.getInstance().setSpeechRate(rate / 10.0f);
                } else {
                    seekBar.setProgress(10);
                    Toast.makeText(CustomizeActivity.this, "错误的语速", Toast.LENGTH_SHORT).show();
                }
            }
        });

        IntentFilter filter = new IntentFilter();
        filter.addAction("aios.intent.action.VOICE_DIALOG_CALLBACK");
        registerReceiver(mVoiceDialogReceiver, filter);


        seek_thresh_percent_value_tv.setText("1.0");
        seek_thresh_percent.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float p = seekBar.getProgress() / 100f;
                seek_thresh_percent_value_tv.setText("" + p);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        seek_thresh_percent_value_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float p = 1.0f;
                try {
                    p = Float.parseFloat(seek_thresh_percent_value_tv.getText().toString().trim());
                    p  = (p > 2f || p < 0f) ? 1.0f : p;

                } catch (Exception e){
                }
                AIOSCustomizeManager.getInstance().setWakeupThreshPercent(p);
            }
        });
    }

    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.btn_customize_reg:
                //注册一条自定义命令，命令串不支持中文、标点和特殊符号，一个命令串可对应多种说法
                Command command = new Command(OPEN_AIR_CONDITION, new String[]{"开启空调", "打开空调", "帮我开空调", "开下空调"});
                //注册单个命令，注册多个消息请见regCommands(List<Command>)
                List<Command> commands = new ArrayList<Command>();
                commands.add(command);
                AIOSCustomizeManager.getInstance().regCommands(commands);
                break;
            case R.id.btn_customize_clean:
                //清空SDK注册的所有自定义命令
                AIOSCustomizeManager.getInstance().cleanCommands();
                break;
            case R.id.btn_customize_scan_disable:
                //关闭APP扫描功能，不生成APP的打开与关闭/退出命令
                AIOSCustomizeManager.getInstance().setScanAppEnabled(false);
                break;
            case R.id.btn_customize_scan_enable:
                //开启APP扫描功能，生成APP的打开与关闭/退出命令
                AIOSCustomizeManager.getInstance().setScanAppEnabled(true);
                break;
            case R.id.btn_reversed_channel_enable:
                //打开通道反转
                AIOSCustomizeManager.getInstance().setReversedChannelEnabled(true);
                break;
            case R.id.btn_reversed_channel_disable:
                //关闭通道反转
                AIOSCustomizeManager.getInstance().setReversedChannelEnabled(false);
                break;
            case R.id.btn_customize_major_wakeup:
                //定制主唤醒词
                List<MajorWakeup> wakeupList = new ArrayList<MajorWakeup>();
                MajorWakeup m1 = new MajorWakeup("你好志玲", "ni hao zhi ling", 0.12f);
                MajorWakeup m2 = new MajorWakeup("你好郭德纲", "ni hao guo de gang", 0.12f);
                MajorWakeup m3 = new MajorWakeup("郭德纲你好", "guo de gang ni hao", 0.12f);
                wakeupList.add(m1);
                wakeupList.add(m2);
                wakeupList.add(m3);
                AIOSCustomizeManager.getInstance().setMajorWakeup(wakeupList);

                break;
            case R.id.btn_customize_launch_tips:
                //定制启动提示语
                AIOSCustomizeManager.getInstance().setLaunchTips("小女子随时为您服务");
                break;
            case R.id.btn_customize_quick_wakeup:
                //定制快捷唤醒词
                List<ShortcutWakeup> shortcutWakeupList = new ArrayList<ShortcutWakeup>();
                shortcutWakeupList.add(new ShortcutWakeup("打开车门", OPEN_DOOR, 0.12f));
                shortcutWakeupList.add(new ShortcutWakeup("关闭车门", CLOSE_DOOR, 0.12f));
                AIOSCustomizeManager.getInstance().registerShortcutWakeups(shortcutWakeupList);
                break;
            case R.id.btn_customize_disable_single:
                //禁用单个原生快捷唤醒词
                AIOSCustomizeManager.getInstance().disableNativeShortcutWakeup(new String[]{"tui chu dao hang"});
                break;
            case R.id.btn_customize_tts_text:
                AILog.d(TAG, CustomizeTTSData.allTips.toString());
                if (System.currentTimeMillis() - timestamp > 60000) {
                    timestamp = System.currentTimeMillis();
                    for (String tip : CustomizeTTSData.allTips) {
                        AIOSTTSManager.speak(tip);
                    }
                }
                break;
            case R.id.btn_customize_notification_voice_dialog:
                Intent intent = new Intent();
                intent.setAction("aios.intent.action.VOICE_DIALOG");
                //语音焦点title
                intent.putExtra("TITLE", "您有未完成的导航信息，请问是否需要继续导航？");
                //肯定操作的多个说法以及反馈语
                intent.putExtra("POSITIVE_PARAMS", new String[]{"是", "需要", "好的", "确定", "导航"});
                intent.putExtra("POSITIVE_TTS_TEXT", "好的，继续为您导航。");
                //否定操作的多个说法以及反馈语
                intent.putExtra("NEGATIVE_PARAMS", new String[]{"否", "不需要", "取消", "退出"});
                intent.putExtra("NEGATIVE_TTS_TEXT", "那我先退下了，有需要再叫我哦");
                sendBroadcast(intent);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //注销监听器
        AIOSCustomizeManager.getInstance().unregisterCustomizeListener();
        unregisterReceiver(mVoiceDialogReceiver);
    }

    private BroadcastReceiver mVoiceDialogReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals("aios.intent.action.VOICE_DIALOG_CALLBACK")) {
                if (intent.hasExtra("VOICE_DIALOG_CALLBACK")) {
                    AILog.d(TAG, "语音焦点操作执行 : " + intent.getBooleanExtra("VOICE_DIALOG_CALLBACK", false));
                }
            }
        }
    };
}
