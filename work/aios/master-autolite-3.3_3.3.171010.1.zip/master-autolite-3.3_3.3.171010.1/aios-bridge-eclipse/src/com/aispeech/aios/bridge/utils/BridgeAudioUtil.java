package com.aispeech.aios.bridge.utils;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import com.aispeech.aios.bridge.BridgeApplication;
import com.aispeech.aios.sdk.utils.AssetsUtil;

/**
 * 音频管理类，可根据具体情况自行改写
 */
public class BridgeAudioUtil {
    private static final String TAG = "BridgeAudioUtil";
    private static AudioManager mAudioManager;
    private static int muteCnt = 0;
    private static Handler mHandler = new Handler(BridgeApplication.getContext().getMainLooper());

    public static void setStreamMute(final Context context, final boolean isMute) {

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (context == null) {
                    return;
                }
                mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                int stream = Integer.valueOf(AssetsUtil.readProp(AssetsUtil.P_PLAYER_STREAM, "4"));
                if (mAudioManager != null) {
                    if (isMute) {
                        muteCnt++;
                        for (int index = 1; index <= 4; index++) {
                            if (index != stream) {
                                mAudioManager.setStreamMute(index, true);
                            }
                        }
                    } else {

                        if (muteCnt == 0) {
                            return;
                        }
                        for (int i = 0; i < getMuteCnt(); i++) {
                            for (int index = 1; index <= 4; index++) {
                                if (index != stream) {
                                    mAudioManager.setStreamMute(index, false);
                                }
                            }
                        }
                        muteCnt = 0;
                    }
                }
            }
        });
    }

    public static int getMuteCnt() {
        return muteCnt;
    }
}
