package com.aispeech.aios.bridge.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.R;
import com.aispeech.aios.bridge.listener.BridgeFmControlListener;
import com.aispeech.aios.common.bean.MediaKey;
import com.aispeech.aios.sdk.AIOSForCarSDK;
import com.aispeech.aios.sdk.bean.ThirdFMInfo;
import com.aispeech.aios.sdk.manager.AIOSFmManager;
import com.aispeech.aios.sdk.manager.AIOSFmManager.OnSearchListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangping on 2016/10/13.
 */
public class FMActivity extends Activity {

    private static final String TAG = "FMActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fm);
    }

    public void onClick(View view) {
        int Id = view.getId();

        switch (Id) {
            case R.id.button_third_fm:
                AIOSFmManager.getInstance().setOnControlListener(new BridgeFmControlListener());
                AIOSFmManager.getInstance().setOnSearchListener(new OnSearchListener() {
                    @Override
                    public void onSearch(String packageName, MediaKey mediaKey) {
                        AILog.d(TAG, "需要搜索的内容为: " + mediaKey.toString());
                        AILog.d(TAG, "第三方FM开始搜索节目,搜索完毕后提交搜索结果");
                        List<ThirdFMInfo> list = new ArrayList<ThirdFMInfo>();

                        ThirdFMInfo object1 = new ThirdFMInfo();
                        object1.setId("12345");
                        object1.setTrack("不差钱");
                        object1.setArtist("小沈阳");
                        object1.setAlbum("小沈阳专辑");
                        list.add(object1);

                        ThirdFMInfo object2 = new ThirdFMInfo();
                        object2.setId("54321");
                        object2.setTrack("不差钱2");
                        object2.setArtist("小沈阳");
                        object2.setAlbum("小沈阳专辑");
                        list.add(object2);

                        AIOSFmManager.getInstance().postFmSearchResult("小沈阳专辑", list);
                    }
                }, AIOSForCarSDK.getPackageName());

                AIOSFmManager.getInstance().setLocalFmInfo("AIOS电台", AIOSForCarSDK.getPackageName());
                AIOSFmManager.getInstance().setDefaultFm(AIOSForCarSDK.getPackageName());
                AIOSFmManager.getInstance().setStrategyEnable(true);
                break;
            case R.id.button_display_fmlist_enable:
                //设置纯搜节目名时，显示结果列表
                AIOSFmManager.getInstance().setDisplayFmListEnabled(true);
                break;
            case R.id.button_display_fmlist_disable:
                //设置纯搜节目名时，不显示结果列表
                AIOSFmManager.getInstance().setDisplayFmListEnabled(false);
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //清除电台应用信息
        AIOSFmManager.getInstance().cleanLocalFmInfo();
        //注销电台监听器
        AIOSFmManager.getInstance().unregisterFmListener();
        AIOSFmManager.getInstance().setDefaultFm(null);
    }
}
