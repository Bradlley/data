package com.aispeech.aios.bridge.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;

/**
 * Created by yangping on 2017/3/1.
 */
public class MapReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //adb shell am broadcast -a "aios.intent.action.map.SIMULATE" --ei "aios.intent.extra.TYPE" 1 --ei "aios.intent.extra.NUM" 1 --ez "aios.intent.extra.HOME" true
        //TYPE  1 更优路线提醒  2 回家、去公司提醒  3 停车场提醒  4  继续导航提醒
        //NUM 个数 ，比如停车场  3个
        //HOME 回家去公司类型  true  回家  false  去公司
        String action = intent.getAction();
        if (action.equals("aios.intent.action.map.SIMULATE")) {
            if (intent.hasExtra("aios.intent.extra.TYPE")) {
                int type = intent.getIntExtra("aios.intent.extra.TYPE", -1);
                switch (type) {
                    case 1:
                        bestRouteMessgae(context);
                        break;
                    case 2:
                        boolean isGoHome = true;
                        if (intent.hasExtra("aios.intent.extra.HOME")) {
                            isGoHome = intent.getBooleanExtra("aios.intent.extra.HOME", true);
                        }
                        goHomeOrCompanyMessage(context, isGoHome);
                        break;
                    case 3:
                        int parkNum = 3;
                        if (intent.hasExtra("aios.intent.extra.NUM")) {
                            parkNum = intent.getIntExtra("aios.intent.extra.NUM", 3);
                            parkNum = parkNum < 1 ? 1 : parkNum;
                            parkNum = parkNum > 3 ? 3 : parkNum;
                        }
                        parkMessage(context, parkNum);
                        break;
                    case 4:
                        continueNaviMessage(context);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    /**
     * 更优路线
     */
    private void bestRouteMessgae(Context context) {
        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_SEND");
        intent.putExtra("KEY_TYPE", 12105);
        intent.putExtra("EXTRA_AVOID_TRAFFIC_JAM_MESSAGE", "hello bridge to MapReceiver");
        context.sendBroadcast(intent);
    }

    /**
     * 回家/去公司
     *
     * @param isGoHome 回家 true  去公司 false
     */
    private void goHomeOrCompanyMessage(Context context, boolean isGoHome) {
        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_SEND");
        intent.putExtra("KEY_TYPE", 12004);
        intent.putExtra("EXTRA_HOME_OR_COMPANY_WHAT", isGoHome);//true：回家；false：回公司
        intent.putExtra("EXTRA_HOME_OR_COMPANY_ETA", "1分钟");//eta时间
        intent.putExtra("EXTRA_MESSAGE_IS_TOP", true);//true该消息在顶部
        context.sendBroadcast(intent);
    }

    /**
     * 停车场
     *
     * @param parkNum 停车场个数
     */
    private void parkMessage(Context context, int parkNum) {
        String data = "";
        if (parkNum == 1) {
            data = "[" +
                    "{\"parkIndex\":0,\"parkName\":\"深圳市软件产业基地B区停车场\",\"parkDistance\":88,\"parkPrice\":\"0\",\"latitude\":22.524486541748047,\"longitude\":113.93682098388672}" +
                    "]";
        } else if (parkNum == 2) {
            data = "[" +
                    "{\"parkIndex\":0,\"parkName\":\"深圳市软件产业基地C区停车场\",\"parkDistance\":75,\"parkPrice\":\"0\",\"latitude\":22.523544311523438,\"longitude\":113.93730163574219}," +
                    "{\"parkIndex\":1,\"parkName\":\"深圳市软件产业基地B区停车场\",\"parkDistance\":88,\"parkPrice\":\"0\",\"latitude\":22.524486541748047,\"longitude\":113.93682098388672}" +
                    "]";
        } else {
            data = "[" +
                    "{\"parkIndex\":0,\"parkName\":\"深圳市软件产业基地C区停车场\",\"parkDistance\":75,\"parkPrice\":\"0\",\"latitude\":22.523544311523438,\"longitude\":113.93730163574219}," +
                    "{\"parkIndex\":1,\"parkName\":\"停车场\",\"parkDistance\":99,\"parkPrice\":\"0\",\"latitude\":22.524917602539063,\"longitude\":113.93706512451172}," +
                    "{\"parkIndex\":2,\"parkName\":\"深圳市软件产业基地B区停车场\",\"parkDistance\":88,\"parkPrice\":\"0\",\"latitude\":22.524486541748047,\"longitude\":113.93682098388672}" +
                    "]";
        }

        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_SEND");
        intent.putExtra("KEY_TYPE", 10052);
        intent.putExtra("EXTRA_PARK_DATA", data);
        context.sendBroadcast(intent);
    }


    /**
     * 继续导航
     */
    private void continueNaviMessage(Context context) {
        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_SEND");
        intent.putExtra("KEY_TYPE", 10049);
        intent.putExtra("EXTRA_ENDURANCE_DATA", "您有未完成的导航，目的地天安门，是否继续导航?");
        context.sendBroadcast(intent);
    }
}
