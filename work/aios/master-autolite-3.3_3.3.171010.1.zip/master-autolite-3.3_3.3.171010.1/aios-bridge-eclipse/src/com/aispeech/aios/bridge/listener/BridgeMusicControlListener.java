package com.aispeech.aios.bridge.listener;

import com.aispeech.ailog.AILog;
import com.aispeech.aios.common.property.MusicProperty.PlayMode;
import com.aispeech.aios.common.property.MusicProperty.PlayState;
import com.aispeech.aios.sdk.bean.ThirdMusicInfo;
import com.aispeech.aios.sdk.manager.AIOSMusicManager;
import com.aispeech.aios.sdk.manager.AIOSMusicManager.OnControlListener;
import com.aispeech.aios.sdk.manager.AIOSTTSManager;
import java.util.List;

/**
 * 音乐监听器类
 */
public class BridgeMusicControlListener extends OnControlListener {

    private static final String TAG = "BridgeMusicControlListener";
    private int playState = PlayState.PAUSE;

    @Override
    public void onPlayOrResume(String packageName) {
        AIOSTTSManager.speak("播放音乐");
        playState = PlayState.PLAYING;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }

    @Override
    public void onPause(String packageName) {
        AIOSTTSManager.speak("播放已暂停");
        playState = PlayState.PAUSE;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }

    @Override
    public void onStop(String packageName) {
        AIOSTTSManager.speak("播放已停止");
        playState = PlayState.STOP;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }

    @Override
    public void onExit(String packageName) {
        AIOSTTSManager.speak("退出音乐");
        playState = PlayState.STOP;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }

    @Override
    public void onPrevious(String packageName) {
        AIOSTTSManager.speak("好的");
        playState = PlayState.PLAYING;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }


    @Override
    public void onNext(String packageName) {
        AIOSTTSManager.speak("好的");
        playState = PlayState.PLAYING;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }

    @Override
    public void onPlaySelected(String packageName, List<ThirdMusicInfo> list) {
        AIOSTTSManager.speak("播放音乐列表");
        AILog.d(TAG, "播放音乐列表：" + list.toString());
        playState = PlayState.PLAYING;

        //如果状态成功改变，调用接口通知AIOS
        AIOSMusicManager.getInstance().setPlayState(playState);
    }

    @Override
    public int getPlayState(String packageName) {
        return playState;
    }


    @Override
    public void onOpen(String packageName) {
        AILog.d(TAG, "[BridgeMusicControlListener#onOpen()] with: packageName = [" + packageName + "]");
        AIOSTTSManager.speak("打开音乐 ");
    }

    @Override
    public void onPlayRandom(String packageName) {
        AIOSTTSManager.speak("音乐随机播放一首歌");
    }

    @Override
    public void onSetPlayMode(String packageName, String mode) {
        if (mode.equals(PlayMode.ORDER)) {
            AIOSTTSManager.speak("顺序播放");

        } else if (mode.equals(PlayMode.SINGLE)) {
            AIOSTTSManager.speak("单曲循环");

        } else if (mode.equals(PlayMode.RANDOM)) {
            AIOSTTSManager.speak("随机播放");

        } else if (mode.equals(PlayMode.CIRCLE)) {
            AIOSTTSManager.speak("列表循环");

        } else {
        }
    }
}
