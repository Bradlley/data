package com.aispeech.aios.bridge.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.R;
import com.aispeech.aios.sdk.listener.OnOptionSelectedListener;
import com.aispeech.aios.sdk.manager.AIOSNotificationManager;

/**
 * 通知领域演示
 *
 * @author rong.liu@aispeech.com
 * @version 2017/4/17
 */
public class NotificationActivity extends Activity {
    private static final String TAG = "NotificationActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
    }

    public void onClick(View view) {
        int id = view.getId();

        switch (id) {
            case R.id.btn_customize_notification:
                AIOSNotificationManager.getInstance().reportNotification("这是一条自定义通知", new OnOptionSelectedListener() {
                    @Override
                    public String onOptionSelected(String action) {
                        AILog.d(TAG, "[NotificationActivity#onOptionSelected()] with: action = [" + action + "]");
                        return "好的";
                    }
                }).addOption("CONFIRM", "确定", "que ding")
                    .addOption("CONFIRM", "导航", "dao hang")
                    .addOption("CONFIRM", "确认", "que ren")
                    .addOption("CANCEL", "取消", "qv xiao")
                    .commit();

                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
