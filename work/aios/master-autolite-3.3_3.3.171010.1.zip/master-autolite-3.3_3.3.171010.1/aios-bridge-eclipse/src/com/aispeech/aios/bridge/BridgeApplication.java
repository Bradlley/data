package com.aispeech.aios.bridge;

import android.app.Application;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.WindowManager;

import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.listener.BridgeAudioListener;
import com.aispeech.aios.bridge.utils.PreferenceUtil;
import com.aispeech.aios.common.bean.MajorWakeup;
import com.aispeech.aios.sdk.AIOSForCarSDK;
import com.aispeech.aios.sdk.listener.AIOSCustomizeListener;
import com.aispeech.aios.sdk.listener.AIOSReadyListener;
import com.aispeech.aios.sdk.manager.AIOSAudioManager;
import com.aispeech.aios.sdk.manager.AIOSCustomizeManager;
import com.aispeech.aios.sdk.manager.AIOSUIManager;

import java.util.ArrayList;
import java.util.List;

/**
 * 自定义Application类
 */
public class BridgeApplication extends Application {

    private static final String TAG = "BridgeApplication";
    private static Context mContext;

    public static Context getContext() {
        if (mContext == null) {
            throw new RuntimeException("Unknown Error");
        }
        return mContext;
    }

    public static BridgeApplication getApplication() {
        if (mContext == null) {
            throw new RuntimeException("Unknown Error");
        }
        return (BridgeApplication) mContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mContext = this;
        AIOSForCarSDK.initialize(this, new AIOSReadyListener() {
            @Override
            public void onAIOSReady() {
                AILog.i(TAG, "[AIOSReadyListener#onAIOSReady]");

                //定制悬浮窗为全屏
                WindowManager.LayoutParams layoutParams = AIOSUIManager.getInstance().obtainLayoutParams();
                layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
                layoutParams.flags = WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
                AIOSUIManager.getInstance().setLayoutParams(layoutParams);

                //设置音频管理监听器，请实现或者使用以下监听器
                AIOSAudioManager.getInstance().registerAudioListener(new BridgeAudioListener());
                //如果静态注册了自定义命令，请注册以下监听器
                AIOSCustomizeManager.getInstance().registerCustomizeListener(customizeListener);
                AIOSCustomizeManager.getInstance().setScanAppEnabled(false);

                AIOSCustomizeManager.getInstance().setWakeupThreshPercent(0.8f);
            }

            /**
             * AIOS（Daemon或者Adapter）重启完成后将会调用该回调
             */
            @Override
            public void onAIOSRebooted() {
                AILog.i(TAG, "[AIOSReadyListener#onAIOSRebooted]");
                //您可以选择此时跟随AIOS重启
                //也可以在此时重新初始化：除了需要手动调用初始化接口外，还需要还原部分初始化接口外调用的主动接口
                onAIOSReady();
            }
        });
    }

    AIOSCustomizeListener customizeListener = new AIOSCustomizeListener() {
        @Override
        public void onCommandEffect(@NonNull String command) {
            AILog.i(TAG, "Command effect: "+command);
        }

        @Override
        public void onShortcutWakeUp(@NonNull String pinyin) {
            AILog.i(TAG, "Short cut wakeup:"+pinyin);
        }
    };
}
