package com.aispeech.aios.bridge.listener;

import com.aispeech.ailog.AILog;
import com.aispeech.aios.common.property.MusicProperty.PlayState;
import com.aispeech.aios.sdk.bean.ThirdFMInfo;
import com.aispeech.aios.sdk.manager.AIOSFmManager;
import com.aispeech.aios.sdk.manager.AIOSFmManager.OnControlListener;
import com.aispeech.aios.sdk.manager.AIOSTTSManager;
import java.util.List;

/**
 * Created by yangping on 2016/10/13.
 */
public class BridgeFmControlListener extends OnControlListener {

    private static final String TAG = "BridgeFmControlListener";

    @Override
    public int getPlayState(String packageName) {
        return PlayState.STOP;
    }

    @Override
    public void onPlayOrResume(String packageName) {
        AIOSTTSManager.speak("第三方FM播放");
        AIOSFmManager.getInstance().setPlayState(PlayState.PLAYING);
    }

    @Override
    public void onPlaySelected(String packageName, List<ThirdFMInfo> fmList) {
        AILog.d(TAG, "[BridgeFmControlListener#onPlaySelected()] with: packageName = [" + packageName + "], fmList = [" + fmList + "]");
        AIOSTTSManager.speak("第三方FM播放列表");
        AIOSFmManager.getInstance().setPlayState(PlayState.PLAYING);
    }

    @Override
    public void onPause(String packageName) {
        AIOSTTSManager.speak("第三方FM暂停");
        AIOSFmManager.getInstance().setPlayState(PlayState.PAUSE);
    }

    @Override
    public void onStop(String packageName) {
        AIOSTTSManager.speak("第三方FM停止");
        AIOSFmManager.getInstance().setPlayState(PlayState.STOP);
    }

    @Override
    public void onExit(String packageName) {
        AIOSTTSManager.speak("第三方FM退出");
        AIOSFmManager.getInstance().setPlayState(PlayState.STOP);
    }

    @Override
    public void onOpen(String packageName) {
        AIOSTTSManager.speak("打开APP ： " + packageName);
    }

    @Override
    public void onPrevious(String packageName) {
        AIOSTTSManager.speak("第三方FM上一首");
        AIOSFmManager.getInstance().setPlayState(PlayState.PLAYING);
    }

    @Override
    public void onNext(String packageName) {
        AIOSTTSManager.speak("第三方FM下一首");
        AIOSFmManager.getInstance().setPlayState(PlayState.PLAYING);
    }

}
