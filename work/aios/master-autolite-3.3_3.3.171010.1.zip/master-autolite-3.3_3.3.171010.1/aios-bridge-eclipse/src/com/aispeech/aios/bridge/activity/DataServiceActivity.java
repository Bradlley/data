package com.aispeech.aios.bridge.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.R;
import com.aispeech.aios.sdk.bean.WeatherBean;
import com.aispeech.aios.sdk.listener.AIOSDataListener;
import com.aispeech.aios.sdk.manager.AIOSDataManager;

import org.json.JSONObject;

import java.util.Date;

/**
 * Created by yangping on 2017/8/14.
 */
public class DataServiceActivity extends Activity{

    private static final String TAG = "DataServiceActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dataservice);
        AIOSDataManager.getInstance().registerDataListener(new AIOSDataListener() {
            @Override
            public void onWeatherResult(JSONObject object) {
                AILog.d(TAG, "天气查询结果\n" + object.toString());
            }
        });
    }

    public void onClick(View view) {
        int Id = view.getId();
        switch (Id) {
            case R.id.button_weather:
                WeatherBean weatherBean = new WeatherBean();
                weatherBean.setCity("深圳");
                weatherBean.setDate(new Date());
                AIOSDataManager.getInstance().queryWeather(weatherBean);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        AIOSDataManager.getInstance().unregisterDataListener();
    }
}
