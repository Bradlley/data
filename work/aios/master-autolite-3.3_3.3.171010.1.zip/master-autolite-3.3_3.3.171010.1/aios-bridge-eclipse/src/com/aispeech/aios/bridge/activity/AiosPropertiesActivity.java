package com.aispeech.aios.bridge.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.aispeech.ailog.AILog;
import com.aispeech.aios.bridge.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Created by yt on 2016/12/1.
 * 读取/system/etc/aios/aios.properties目录下的aios.properties文件
 * 获取property属性值，展示出来，针对其中某些属性值进行并合理性判断
 */

public class AiosPropertiesActivity extends Activity implements View.OnClickListener {
    private final String TAG = "AiosPropertiesActivity";


    private final String FILE_PATH_AIOS_PROPERTIES = "/system/etc/aios/aios.properties";
    private final String FILE_PATH_WECHAT_PROPERTIES = "/system/etc/aios/wechat.properties";

    private List<PropertiesBean> mAiosPropertiesList;
    private List<PropertiesBean> mWechatPropertiesList;
    /**
     * 合法的值
     */
    private final String mReasonable = "合法";

    /**
     * 不合法的值
     */
    private final String mUnreasonable = "不合法";

    private ListView mLvActivityAiosProperties;
    private Button mBtnAiosProperties, mBtnWechatProperties;

    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aios_properties);
        mBtnAiosProperties = (Button) findViewById(R.id.BtnAiosProperties);
        mBtnWechatProperties = (Button) findViewById(R.id.BtnWechatProperties);
        mBtnAiosProperties.setOnClickListener(this);
        mBtnWechatProperties.setOnClickListener(this);
        mBtnAiosProperties.setTextColor(this.getResources().getColor(android.R.color.holo_red_dark));

        mLvActivityAiosProperties = (ListView) findViewById(R.id.LvActivityAiosProperties);
        loadAiosProperties();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.BtnAiosProperties:
                mBtnAiosProperties.setTextColor(this.getResources().getColor(android.R.color.holo_red_dark));
                mBtnWechatProperties.setTextColor(this.getResources().getColor(android.R.color.black));
                loadAiosProperties();
                break;

            case R.id.BtnWechatProperties:
                mBtnAiosProperties.setTextColor(this.getResources().getColor(android.R.color.black));
                mBtnWechatProperties.setTextColor(this.getResources().getColor(android.R.color.holo_red_dark));
                loadWechatProperties();
                break;
        }
    }

    /**
     * 加载属性文件内容
     */
    private void loadAiosProperties() {
        if(myAdapter != null){
            myAdapter.setData(null);
        }
        File file = new File(FILE_PATH_AIOS_PROPERTIES);
        if (file.exists()) {
            Properties properties = new Properties();
            try {
                FileInputStream s = new FileInputStream(file);
                InputStreamReader reader = new InputStreamReader(s, "UTF-8");
                properties.load(reader);
                Log.d(TAG, "loadAiosProperties: " + properties.isEmpty());
                if (!properties.isEmpty()) {
                    aiosPropertiesDataAnalysis(properties);
                } else {
                    Toast.makeText(this, "文件无内容", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "读取文件失败", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "/system/etc/aios/目录下没有aios.properties配置文件", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 属性文件数据分析
     */
    private void aiosPropertiesDataAnalysis(Properties properties) {
        if (mAiosPropertiesList == null) {
            mAiosPropertiesList = new ArrayList<PropertiesBean>();
        }
        mAiosPropertiesList.clear();
        Iterator it = properties.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String key = entry.getKey().toString();
            String value = entry.getValue().toString();
            AILog.d(TAG, key + " = " + value);
            if (key.equals(AiosPropertyKeys.ro_cloud_server)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_cloud_server, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_bugly_report_id)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_bugly_report_id, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_aios_activation_key)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aios_activation_key, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_aios_app_key)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aios_app_key, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_aios_secret_key)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aios_secret_key, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_aios_user_id)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aios_user_id, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_wakeup_major)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_wakeup_major, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_reversed_channel)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_reversed_channel, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_reversed_channel, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_tts_audio_track_vol)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_tts_audio_track_vol, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_aios_player_stream)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aios_player_stream, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_first_boot_auto_start)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_first_boot_auto_start, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_first_boot_auto_start, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_oneshot_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_oneshot_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_oneshot_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_interrupt_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_interrupt_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_interrupt_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_wakeup_command_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_wakeup_command_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_wakeup_command_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_poi_cluster_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_poi_cluster_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_poi_cluster_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_num_correct_enable)) {
//                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
//                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_num_correct_enable, value, mReasonable));
//                } else {
//                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_num_correct_enable, value, mUnreasonable));
//                }
            } else if (key.equals(AiosPropertyKeys.ro_callin_broadcast)) {
//                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
//                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_callin_broadcast, value, mReasonable));
//                } else {
//                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_callin_broadcast, value, mUnreasonable));
//                }
            } else if (key.equals(AiosPropertyKeys.ro_music_list)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_music_list, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_music_list, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_netfm_list)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_netfm_list, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_netfm_list, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_wakeup_exclude_command)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_wakeup_exclude_command, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_modules_include)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_modules_include, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_tts_param)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_tts_param, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_jpush_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_jpush_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_jpush_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.ro_asr_record_timeout)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_asr_record_timeout, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_delay_in_boot)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_delay_in_boot, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_launch_tips)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_launch_tips, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_delay_on_startup_tips)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_delay_on_startup_tips, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_wechat_vad_pause_time)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_wechat_vad_pause_time, value, null));
            } else if (key.equals(AiosPropertyKeys.ro_aec_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aec_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.ro_aec_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.log_level)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.log_level, value, null));
            } else if (key.equals(AiosPropertyKeys.my_location)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.my_location, value, null));
            } else if (key.equals(AiosPropertyKeys.wakeup_enable)) {
                if (!TextUtils.isEmpty(value) && (value.equals("true") || value.equals("false"))) {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.wakeup_enable, value, mReasonable));
                } else {
                    mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.wakeup_enable, value, mUnreasonable));
                }
            } else if (key.equals(AiosPropertyKeys.tts_res)) {
                mAiosPropertiesList.add(new PropertiesBean(AiosPropertyKeys.tts_res, value, null));
            }
        }
        if (!mAiosPropertiesList.isEmpty() && mAiosPropertiesList.size() > 0) {
            if (myAdapter == null) {
                myAdapter = new MyAdapter(AiosPropertiesActivity.this);
            }
            myAdapter.setData(mAiosPropertiesList);
            mLvActivityAiosProperties.setAdapter(myAdapter);
        }
    }

    /**
     * 加载属性文件内容
     */
    private void loadWechatProperties() {
        if(myAdapter != null){
            myAdapter.setData(null);
        }
        File file = new File(FILE_PATH_WECHAT_PROPERTIES);
        if (file.exists()) {
            Properties properties = new Properties();
            try {
                FileInputStream s = new FileInputStream(file);
                InputStreamReader reader = new InputStreamReader(s, "UTF-8");
                properties.load(reader);
                Log.d(TAG, "loadAiosProperties: " + properties.isEmpty());
                if (!properties.isEmpty()) {
                    wechatPropertiesDataAnalysis(properties);
                } else {
                    Toast.makeText(this, "文件无内容", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "读取文件失败", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "/system/etc/aios/目录下没有wechat.properties配置文件", Toast.LENGTH_SHORT).show();
        }
    }

    private void wechatPropertiesDataAnalysis(Properties properties) {
        if (mWechatPropertiesList == null) {
            mWechatPropertiesList = new ArrayList<PropertiesBean>();
        }
        mWechatPropertiesList.clear();
        Iterator it = properties.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String key = entry.getKey().toString();
            String value = entry.getValue().toString();
            AILog.d(TAG, key + " = " + value);

            if (key.equals(WechatPropertyKeys.wechat_public_qrcode)) {
                mWechatPropertiesList.add(new PropertiesBean(WechatPropertyKeys.wechat_public_qrcode, value, null));
            } else if (key.equals(WechatPropertyKeys.wechat_player_stream)) {
                mWechatPropertiesList.add(new PropertiesBean(WechatPropertyKeys.wechat_player_stream, value, null));
            }
        }

        if (!mWechatPropertiesList.isEmpty() && mWechatPropertiesList.size() > 0) {
            if (myAdapter == null) {
                myAdapter = new MyAdapter(AiosPropertiesActivity.this);
            }
            myAdapter.setData(mWechatPropertiesList);
            mLvActivityAiosProperties.setAdapter(myAdapter);
        }
    }

    private class MyAdapter extends BaseAdapter {
        private List<PropertiesBean> propertiesBeans;
        private LayoutInflater inflater;

        public MyAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        public void setData(List<PropertiesBean> propertiesBeansList) {
            this.propertiesBeans = propertiesBeansList;
            this.notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return propertiesBeans != null?propertiesBeans.size():0;
        }

        @Override
        public Object getItem(int position) {
            return propertiesBeans != null?propertiesBeans.get(position):null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.activity_aios_properties_item, null);
                viewHolder = new ViewHolder();
                viewHolder.tvPropertyName = (TextView) convertView.findViewById(R.id.TvPropertyName);
                viewHolder.tvPropertyValue = (TextView) convertView.findViewById(R.id.TvPropertyValue);
                viewHolder.tvPropertyValueRationality = (TextView) convertView.findViewById(R.id.TvPropertyValueRationality);
                convertView.setTag(viewHolder);
            }
            viewHolder = (ViewHolder) convertView.getTag();
            viewHolder.tvPropertyName.setText("属性名:" + propertiesBeans.get(position).getPropertyName());
            viewHolder.tvPropertyValue.setText("属性值:" + propertiesBeans.get(position).getPropertyValue());
            String propertyValueRationality = propertiesBeans.get(position).getPropertyValueRationality();
            if (TextUtils.isEmpty(propertyValueRationality)) {
                viewHolder.tvPropertyValueRationality.setText("");
            } else {
                viewHolder.tvPropertyValueRationality.setText("属性值合法性:" + propertyValueRationality);
            }
            return convertView;
        }

        public class ViewHolder {
            TextView tvPropertyName;
            TextView tvPropertyValue;
            TextView tvPropertyValueRationality;
        }
    }

    private class PropertiesBean {
        //属性名
        private String propertyName;
        //属性值
        private String propertyValue;
        //当前属性值合理性
        private String propertyValueRationality;

        /**
         * @param propertyName             属性名
         * @param propertyValue            属性值
         * @param propertyValueRationality 当前属性值合理性
         */
        public PropertiesBean(String propertyName, String propertyValue, String propertyValueRationality) {
            this.propertyName = propertyName;
            this.propertyValue = propertyValue;
            this.propertyValueRationality = propertyValueRationality;
        }

        public String getPropertyName() {
            return propertyName;
        }

        public String getPropertyValue() {
            return propertyValue;
        }

        public String getPropertyValueRationality() {
            return propertyValueRationality;
        }
    }

    public class AiosPropertyKeys {
        /**
         * #语音云服务地址
         * ro_cloud_server =
         */
        public static final String ro_cloud_server = "ro_cloud_server";

        /**
         * #BUGLY应用程序KEY
         * ro_bugly_report_id =
         */
        public static final String ro_bugly_report_id = "ro_bugly_report_id";

        /**
         * #AIOS激活码
         * ro_aios_activation_key =
         */
        public static final String ro_aios_activation_key = "ro_aios_activation_key";

        /**
         * ## AIOS应用程序KEY
         * ro_aios_app_key =
         */
        public static final String ro_aios_app_key = "ro_aios_app_key";

        /**
         * ## AIOS密钥
         * ro_aios_secret_key =
         */
        public static final String ro_aios_secret_key = "ro_aios_secret_key";

        /**
         * ## AIOS用户标识-YUNOS系统平台-方案商-厂家-型号
         * ro_aios_user_id = public
         */
        public static final String ro_aios_user_id = "ro_aios_user_id";

        /**
         * 主唤醒词及阈值
         * ro_wakeup_major = [{	"name": "你好小驰", 	"pinyin": "ni hao xiao chi", 	"threshold": "0.066"}, {	"name": "小驰你好 ", 	"pinyin": "xiao chi ni hao", 	"threshold": "0.066"}]
         */
        public static final String ro_wakeup_major = "ro_wakeup_major";

        /**
         * 录音通道是否反转, 缺省为不反转
         * ro_reversed_channel = false
         */
        public static final String ro_reversed_channel = "ro_reversed_channel";

        /**
         * ## TTS AudioTrack音量, 缺省为1.0
         * ro_tts_audio_track_vol = 1.0
         */
        public static final String ro_tts_audio_track_vol = "ro_tts_audio_track_vol";

        /**
         * ## TTS使用的Audio Stream类型, 缺省为4(Alarm), 参考AudioManager.Stream_Type
         * ro_aios_player_stream = 4
         */
        public static final String ro_aios_player_stream = "ro_aios_player_stream";

        /**
         * ## 安装或者恢复出厂设置后, 语音是否自启动, 缺省开启
         * ro_first_boot_auto_start = true
         */
        public static final String ro_first_boot_auto_start = "ro_first_boot_auto_start";

        /**
         * ## oneshot开关, 缺省开启
         * ro_oneshot_enable = true
         */
        public static final String ro_oneshot_enable = "ro_oneshot_enable";

        /**
         * ## 唤醒打断开关, 缺省开启
         * ro_interrupt_enable = true
         */
        public static final String ro_interrupt_enable = "ro_interrupt_enable";

        /**
         * ## 快捷唤醒总开关, 缺省开启
         * ro_wakeup_command_enable = true
         */
        public static final String ro_wakeup_command_enable = "ro_wakeup_command_enable";

        /**
         * ## POI聚类开关, 缺省关闭
         * ro_poi_cluster_enable = false
         */
        public static final String ro_poi_cluster_enable = "ro_poi_cluster_enable";

        /**
         * ## 号码纠正, 缺省关闭
         * ro_num_correct_enable = false
         */
        public static final String ro_num_correct_enable = "ro_num_correct_enable";

        /**
         * ## 来电播报开关, 缺省打开
         * ro_callin_broadcast = true
         */
        public static final String ro_callin_broadcast = "ro_callin_broadcast";

        /**
         * ## 音乐列表展示开关, 缺省关闭
         * ro_music_list = false
         */
        public static final String ro_music_list = "ro_music_list";

        /**
         * ## 网络电台列表展示开关, 缺省关闭
         * ro_netfm_list = false
         */
        public static final String ro_netfm_list = "ro_netfm_list";

        /**
         * ## 需要移除的快捷唤醒词, 缺省不移除任何快捷唤醒命令
         * ro_wakeup_exclude_command =
         */
        public static final String ro_wakeup_exclude_command = "ro_wakeup_exclude_command";

        /**
         * ## 大功能开关, 缺省为全功能可用
         * ro_modules_include = { "radio": true, "stock": true, "weather": true, "vehiclerestriction": true,  "vehiclemaintenance":true,  "trafficstate": true, "notification": true, "chat": true, "command": true, "navi": true, "music": true, "nearby": true, "phonecall": true, "callin": true,  "wechat":true,  "netfm":true,  "calendar":true,  "recall": true,  "wakeupwords":true }
         */
        public static final String ro_modules_include = "ro_modules_include";

        /**
         * ## 各个合成模型的参数
         * ro_tts_param = [{  "res": "guo-de-gang",  "volume": 100,  "speechrate": 0.9}, {  "res": "lin-zhi-ling",  "volume": 50,  "speechrate": 0.85}]
         */
        public static final String ro_tts_param = "ro_tts_param";

        /**
         * ## 是否启用JPUSH组件, 缺省开启，有些项目不需要，比如YUNOS，请配置为false
         * ro_jpush_enable = true
         */
        public static final String ro_jpush_enable = "ro_jpush_enable";

        /**
         * #录音时长的限制，默认20秒，该值的单位毫秒
         * ro_asr_record_timeout = 20000
         */
        public static final String ro_asr_record_timeout = "ro_asr_record_timeout";

        /**
         * # 延迟启动aios
         * ro_delay_in_boot = 0
         */
        public static final String ro_delay_in_boot = "ro_delay_in_boot";

        /**
         * # aios启动播报音
         * ro_launch_tips = 语音已启动
         */
        public static final String ro_launch_tips = "ro_launch_tips";

        /**
         * # aios启动播报音延迟
         * ro_delay_on_startup_tips = 0
         */
        public static final String ro_delay_on_startup_tips = "ro_delay_on_startup_tips";

        /**
         * # 微信延迟时间
         * ro_wechat_vad_pause_time = 1000
         */
        public static final String ro_wechat_vad_pause_time = "ro_wechat_vad_pause_time";

        /**
         * ## AEC开关, 缺省为开启AEC
         * ro_aec_enable = true
         */
        public static final String ro_aec_enable = "ro_aec_enable";

        /**
         * # loglevel默认值
         * log_level = 4
         */
        public static final String log_level = "log_level";

        /**
         * # 我的位置默认值
         * my_location =
         */
        public static final String my_location = "my_location";

        /**
         * ## 唤醒总开关, 关闭后快捷唤醒也失效, 缺省开启
         * wakeup_enable = true
         */
        public static final String wakeup_enable = "wakeup_enable";

        /**
         * # tts资源默认值
         * tts_res = lin-zhi-ling
         */
        public static final String tts_res = "tts_res";

    }

    public class WechatPropertyKeys {
        /**
         * #是否显示AIOS微信公众号扫描二维码
         * wechat_public_qrcode = disable
         */
        public static final String wechat_public_qrcode = "wechat_public_qrcode";

        /**
         * #微信播放通道
         * wechat_player_stream = 1
         */
        public static final String wechat_player_stream = "wechat_player_stream";
    }
}
