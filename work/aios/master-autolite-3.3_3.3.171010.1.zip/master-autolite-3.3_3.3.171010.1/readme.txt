[Version] 
'com.aispeech.aios.adapter' versionCode='101' versionName='3.3.171010.1' 
'com.aispeech.aios.bridge' versionCode='67' versionName='3.3.171010.1' 
'com.aispeech.aios' versionCode='102' versionName='3.3.171010.1' 
'com.aispeech.aios.wechat' versionCode='100' versionName='3.3.15.171010.1' 
 

--------
1.
[Feature][工具][Added]3.3开路者添加repairman，当前版本号为2.1，增加aios状态
[需求来源]
repairman增加aios状态
[实现方案]
repairman增加aios状态
[影响范围]
[测试建议]
[备注]

2.
[Feature][工具][Added]3.3开路者添加repairman，当前版本号为2.1
[需求来源]
同步录音工具
[实现方案]
移植
[影响范围]
暂无
[测试建议]
请使用
[备注]
暂无

3.
[Feature][音乐][Modified]更新酷我SDK1.9.3，酷我车镜版本3.6.0.1，酷我车机版本4.0.1.1
[需求来源]
酷我SDK更新
[实现方案]
更新酷我SDK1.9.3，酷我车镜版本3.6.0.1，酷我车机版本4.0.1.1
[影响范围]
酷我音乐
[测试建议]
[备注]

4.
[Bug][代码同步][Modified]修正同步错误代码
[问题来源]
修正同步错误代码
[根本原因]
[修改描述]
修正同步错误代码
[影响范围]
[测试建议]
[备注]

5.
[Bug][动态授权][Modified]动态权限申请
[问题来源]
同步动态授权
[根本原因]
没有动态授权
[修改描述]
增加动态授权
[影响范围]
[测试建议]
[备注]

6.
[Feature][地图][Modified]FIX腾讯地图逻辑 TODO 腾讯更新导航状态时，需更新代码
[需求来源]
腾讯地图更新
[实现方案]
更新腾讯地图
[影响范围]
腾讯地图
[测试建议]
[备注]

7.
[Bug][导航][Modified]TODO规避腾讯地图退出导航交互，（腾讯地图在后台不接收退出导航广播）
[问题来源]
腾讯地图在后台，会一直响应退出导航。
[根本原因]
腾讯地图在后台没正确处理退出导航
[修改描述]
TODO规避腾讯地图退出导航交互
[影响范围]
[测试建议]
[备注]

8.
[Bug][导航][Modified]优化高德定制判断以及腾讯地图关闭了之后响应退出导航
[问题来源]
代码优化
[根本原因]
优化代码
[修改描述]
优化高德定制判断以及腾讯地图关闭了之后响应退出导航
[影响范围]
[测试建议]
[备注]

9.
[Bug][导航][Modified]修改播报语，导航后台，控制命令北朝上反馈暂无暂无地图应用在前台。
[问题来源]
Fixes AIOSPUBLIC-5502
[根本原因]
此时地图已经打开，播报了  没有已经打开的地图应用
[修改描述]
播报  暂无暂无地图应用在前台
[影响范围]
[测试建议]
[备注]

10.
[Bug][导航/音乐][Modified]同步音乐adapter崩溃
[问题来源]
Fixes AIOSPUBLIC-5542 偶现mic消失
[根本原因]
此时在同步音乐导致崩溃
[修改描述]
增加崩溃处理
[影响范围]
[测试建议]
[备注]

11.
[Bug][导航][Modified]路径规划时选择地址一直提示选择超出范围 AIOSPUBLIC-5511 GAODE-212
[问题来源]
Fixes AIOSPUBLIC-5511 GAODE-212
[根本原因]
路径规划没同步列表信息
[修改描述]
同步列表信息
[影响范围]
[测试建议]
[备注]

12.
commit 4c9c6fc57bfcf2369eba67eaaf47e4830723626d
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Sep 7 19:00:36 2017 +0800
路径规划时选择地址一直提示选择超出范围 AIOSPUBLIC-5511 GAODE-212
commit c0abed87da2a8d7ece3c503fc5e635b890cdb509
Merge: 0ca75eb 35b2d58
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Sep 6 21:13:06 2017 +0800
13.
[Bug][导航][Modified]腾讯地图增加运行状态检查 AIOSPUBLIC-5532 AIOSPUBLIC-5553
[问题来源]
Fixes AIOSPUBLIC-5532 AIOSPUBLIC-5553
[根本原因]
内核增加运行状态检查
[修改描述]
Android增加运行状态返回
[影响范围]
[测试建议]
[备注]

14.
[Bug][UI][Modified]导航界面唤醒去XXX，在adapter界面点击快捷按钮Mic，界面无变化 AIOSPUBLIC-5543
[问题来源]
Fixes AIOSPUBLIC-5543
[根本原因]
高德在前台时事件被拦截
[修改描述]
根据判断修改事件拦截
[影响范围]
UI展示
[测试建议]
[备注]

15.
[Bug][UI][Modified]Adapter界面点击MIC  语音已暂停，请重新唤醒使用
[问题来源]
Fixes AIOSPUBLIC-5505
[根本原因]
提示语未修改
[修改描述]
修改提示语为 ： 语音已暂停，请重新唤醒使用
[影响范围]
[测试建议]
[备注]

16.
[Bug][接口][Modified]完善  新增地图、默认地图设置接口 验证，更方便
[问题来源]
Fixes AIOSPUBLIC-5477
[根本原因]
接口调用不对
[修改描述]
用bridge来完善接口验证
[影响范围]
[测试建议]
bridge  地图模块 ，点击对接bridge地图，设置默认地图，观察
[备注]

17.
[Bug][导航][Modified]高版本替换成低版本，导航去xxx，出现选择路线界面 AIOSPUBLIC-5544
[问题来源]
AIOSPUBLIC-5544
[根本原因]
地图更新时未更新路径规划配置
[修改描述]
地图更新时，更新配置
[影响范围]
[测试建议]
高德车镜高版本到低版本切换是否异常
[备注]

18.
[Bug][通知][Modified]目的地停车场推荐不支持语音选择 AIOSPUBLIC-5470
[问题来源]
Fixes AIOSPUBLIC-5470
[根本原因]
老版本代码不支持
[修改描述]
增加语音选择支持
[影响范围]
[测试建议]
[备注]

19.
[Bug][导航][Modified]导航时搜索Poi，选择时可以超出本页显示的个数 AIOSPUBLIC-5538
[问题来源]
Fixes AIOSPUBLIC-5538
[根本原因]
filllist时，未更新每页显示个数
[修改描述]
根据判断，动态更新每页显示个数
[影响范围]
[测试建议]
[备注]

20.
[Bug][导航][Modified]沿途经过的Poi大于1 AIOSPUBLIC-5541
[问题来源]
Fixes AIOSPUBLIC-5541
[根本原因]
在导航的时候，高德支持的几个附近类型，都为沿途(之前一明定义)，未删除途经点
[修改描述]
删除之前所有途经点
[影响范围]
导航时，搜索沿途，附近高德支持类型
[测试建议]
[备注]

21.
commit 14ec7349d6edc91a975249cfa0380a68a7f5dcf4
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Sep 5 16:56:50 2017 +0800
沿途经过的Poi大于1 AIOSPUBLIC-5541
commit 9df6c938021f2f04c858d7b12990df374e56b23d
Merge: 8a5026d 64b8052
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Sep 5 16:44:22 2017 +0800
22.
[Bug][导航][Modified]搜索附近领域，不会显示poi列表
[问题来源]
Fixes AIOSPUBLIC-5507
[根本原因]
未在高德搜索，此时高德无显示界面
[修改描述]
附近领域不在高德地图搜了，高德没有电话，不管在什么情况都需要展示AIOS界面
[影响范围]
[测试建议]
[备注]

23.
[Bug][SDK][Modified]FIX oncall在getAIOSState超时
[问题来源]
同步普方达oncall在getAIOSState超时
[根本原因]
oncall 超时ANR
[修改描述]
同步普方达oncall在getAIOSState超时
[影响范围]
[测试建议]
[备注]

24.
解决：AIOS-Public/AIOSPUBLIC-5542
[问题来源]
Fixes AIOSPUBLIC-5542
[根本原因]
说确定时，没有处理
[修改描述]
在确定类说法时，增加响应
[影响范围]
3.3
[测试建议]
[备注]
-----标题模板（请贴到标题后请删除）-----
[Bug][导航][Modified]解决：AIOS-Public/AIOSPUBLIC-5542

25.
[Feature][合并][Modified]合并3.3开路者
[需求来源]
合并3.3开路者
[实现方案]
合并3.3开路者
[影响范围]
ALL
[测试建议]
全功能测试
[备注]

26.
解决vad状态和悬浮MIC动效不匹配，减少vad状态抖动对动效影响
解决vad状态和悬浮MIC动效不匹配，减少vad状态抖动对动效影响

27.
AIOSPUBLIC-5471 唤醒后点击MIC，MIC一直处于聆听状态不会变化
AIOSPUBLIC-5471 唤醒后点击MIC，MIC一直处于聆听状态不会变化

28.
AIOSPUBLIC-5263 是否继续上次导航播报时没有打断、bridge module编译出错等
AIOSPUBLIC-5263 是否继续上次导航播报时没有打断
AIOSPUBLIC-5478 bridge module编译出错
AIOSPUBLIC-5469 搜索附近的好吃的/酒店等，poi的电话图标为灰 、ACC OFF消息悬浮窗消失语音还在对话，‘语音已暂停，请重新唤醒使用’

29.
用户点击mic场景不加isVoiceWakeup判断
用户点击mic场景不加isVoiceWakeup判断

30.
修复遗漏提交的jar以及vad.state连续发多轮状态的悬浮窗动效处理
修复遗漏提交的jar以及vad.state连续发多轮状态的悬浮窗动效处理

31.
[Bug][导航][Modified]未在导航时，退出导航/关闭导航->关闭APP AIOSPUBLIC-5392
[问题来源]
AIOSPUBLIC-5392
[根本原因]
退出导航关闭导航无效,需同步3.2代码
[修改描述]
同步3.2开路者代码，未在导航时，退出导航/关闭导航->关闭APP
[影响范围]
[测试建议]
[备注]

32.
[Bug][微信][Modified]导航界面，唤醒说“发微信”，播报不全  AIOSPUBLIC-5449
[问题来源]
Fixes AIOSPUBLIC-5449
[根本原因]
进入微信领域没有消息通知
[修改描述]
进入微信领域时给出消息通知
[影响范围]
[测试建议]
[备注]

33.
34.
修复aios-sdk编译失败的错误
[问题来源]
版本编译
[根本原因]
javabean未实现Parcel相关方法
[修改描述]
实现Parcel方法
[影响范围]
aios-sdk.jar生成与否
[测试建议]
确认aios-sdk.jar是否生成
[备注]
-----标题模板（请贴到标题后请删除）-----
[Bug][模块或功能][Added/Modified/Deleted]commit title


35.
修复aios-sdk编译失败的错误
[问题来源]
版本编译
[根本原因]
javabean未实现Parcel相关方法
[修改描述]
实现Parcel方法
[影响范围]
aios-sdk.jar生成与否
[测试建议]
确认aios-sdk.jar是否生成
[备注]
-----标题模板（请贴到标题后请删除）-----
[Bug][模块或功能][Added/Modified/Deleted]commit title

36.
把3.2版本SDK的优化部分合入到3.3开路者版本中
把3.2版本SDK的优化部分合入到3.3开路者版本中

37.
加ACC OFF时候悬浮窗消除处理、增加了adapter TTS抽取的代码和ACC off和ACC ON处理的遗漏提交代码
增加了adapter TTS抽取的代码和ACC off和ACC ON处理的遗漏提交代码
增加ACC OFF时候悬浮窗消除处理

38.
AIOSPUBLIC-5392 退出导航关闭导航无效
AIOSPUBLIC-5392 退出导航关闭导航无效

39.
AIOSPUBLIC-5394 唤醒后点击Mic，不会反馈语音已暂停，请重新唤醒使用
AIOSPUBLIC-5394 唤醒后点击Mic，不会反馈语音已暂停，请重新唤醒使用

40.
修复微信联系人翻页不响应问题
[问题来源]
https://jira.spetechcular.com/jira/browse/AIOSPUBLIC-5393
[根本原因]
版本合并引起的问题
之前homenode中一直是响应public翻页, 合并版本后微信改为call发出翻页指令
[修改描述]
在homenode中将翻页有onmessage中转为oncall处理 , 翻页播报转到内核控制
[影响范围]
开路者版本
[测试建议]
1, 唤醒->我要发微信->上下翻页操作
2, 唤醒->发微信给xxx(多个类似联系人名) -> 上下翻页操作
[备注]

41.
移除被删除的接口方法
移除被删除的接口方法

42.
AIOSPUBLIC-5284  周边路况播报的位置不正确
AIOSPUBLIC-5284
周边路况播报的位置不正确

43.
合并微信
合并微信

44.
修复xxx..getBusClient().xxx()引起空指针
修复xxx..getBusClient().xxx()引起空指针

45.
修复有加载操作时，输出被前一次输入冲掉的问题、Fix AIL-180
修复有加载操作时，输出被前一次输入冲掉的问题
Fix AIL-180 NullPointerException

46.
继续导航提醒不弹出语音界面
继续导航提醒不弹出语音界面

47.
1，去除adapter自动化插桩，后续在autotest.apk维护
1，去除adapter自动化插桩，后续在autotest.apk维护

48.
新增通知领域，用于提供一次无界面的单轮交互
新增通知领域，用于提供一次无界面的单轮交互

49.
新增FM发射对接接口
新增FM发射对接接口

50.
1. 修改倾听、识别状态发出的时机；2. 新增是否隐藏通知栏的接口；新增vad pause time配置项、录音机AudioRecord audioSource 配置化
1. 修改倾听、识别状态发出的时机；
2. 新增是否隐藏通知栏的接口
3. 新增vad pause time配置项
4.录音机AudioRecord audioSource 配置化
5.恢复bugly

51.
语音未联网授权时，导致音乐播放没有声音、蓝牙失去连接时候。将offhook状态重置
1、语音未联网授权时，导致音乐播放没有声音
2、蓝牙失去连接时候。将offhook状态重置

52.
[Bug][player][Modified]同步更新合入PlayerNode爆破声
[问题来源]
合步爆破声合入
[根本原因]
同步3.1代码
[修改描述]
[影响范围]
[测试建议]
[备注]

53.
commit 3149da22d51b4b61051878206c733f9866752ec0
Merge: be5cde8 30dcd66
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Jul 4 15:54:01 2017 +0800
54.
周边路况没有播报、修复获取授权失败空指针、微信 录音界面点击右侧mic图标，还会有“叮咚”声
1、周边路况没有播报
2、修复获取授权失败空指针
3、微信 录音界面点击右侧mic图标，还会有“叮咚”声

55.
防止空指针，onCall超时导致语音重启
防止空指针，onCall超时导致语音重启

56.
AIL-567 修复股票停牌的界面显示
[问题来源]
修复股票停牌的界面显示
Fixes AIL-567
[根本原因]
停牌股票未有数值显示
[修改描述]
增加刻度显示以及线条颜色加深
[影响范围]
[测试建议]
[备注]
-----标题模板（请贴到标题后请删除）-----
[Bug][模块或功能][Added/Modified/Deleted]commit title

57.
[Bug][电台][Modified]增加切换电台响应
[问题来源]
Fixes AIOSPUBLIC-5231
[根本原因]
切换电台，喜马拉雅，车悦宝未实现
[修改描述]
实现喜马拉雅，车悦宝的切换电台操作
[影响范围]
电台
[测试建议]
[备注]

58.
将订阅代码提前
https://gitlab.spetechcular.com/aios/aios-for-car-android/merge_requests/2788/diffs

59.
[Bug][导航][Modified]修复查询路况之后再查询当前位置地图显示不正确问题
[问题来源]
Fixes AIOSPUBLIC-5206
[根本原因]
调用显示地图位置不对
[修改描述]
调整调用地图显示位置
[影响范围]
[测试建议]
[备注]

60.
[Bug][音乐][Modified]我要听情歌，播报两次网络条件不佳
[问题来源]
Fixes AIOSPUBLIC-5011
[根本原因]
搜索时，参数不正确未返回
[修改描述]
搜索时，参数不正确增加返回
[影响范围]
[测试建议]
[备注]

61.
[Bug][音乐][Modified]同步3.2 清除本地音乐后，语音请求播放xxx的歌无法调用酷我音乐
[问题来源]
Fixes AIOSPUBLIC-4191 AIOSPUBLIC-4462
[根本原因]
清空本地音乐时更新aimedia配置有误
[修改描述]
清空本地音乐时，重新检查aimedia配置
[影响范围]
音乐，电台
[测试建议]
按照单上步骤测试
[备注]

62.
[Bug][电台][Modified]修复喜马拉雅暂停之后会自动播放（服务挂掉会自动播放、音频焦点获取到之后偶现自动播放）
[问题来源]
Fixes AIOSPUBLIC-5023
[根本原因]
喜马拉雅暂停之后会自动播放（服务挂掉会自动播放、音频焦点获取到之后偶现自动播放）
[修改描述]
喜马拉雅暂停之后会自动播放，增加手动暂停处理
[影响范围]
喜马拉雅
[测试建议]
[备注]

63.
[Bug][电台][Modified]修复喜马拉雅暂停之后会自动播放（服务挂掉会自动播放、音频焦点获取到之后偶现自动播放）
[问题来源]
Fixes AIOSPUBLIC-5023
[根本原因]
喜马拉雅暂停之后会自动播放（服务挂掉会自动播放、音频焦点获取到之后偶现自动播放）
[修改描述]
喜马拉雅暂停之后会自动播放，增加手动暂停处理
[影响范围]
喜马拉雅
[测试建议]
[备注]

64.
[Bug][音乐][Modified]修复酷我音乐播放时，列表模式id为空
[问题来源]
Fixes EASYNAVI-26
[根本原因]
列表上模式酷我音乐id为空
[修改描述]
增加判断，避免id为空情况
[影响范围]
[测试建议]
[备注]

65.
[Bug][媒体][Modified]增加媒体状态判断返回 ： [播放，暂停，未运行，其他以及未安装状态]
[问题来源]
Fixes AIOSPUBLIC-4172
[根本原因]
未安装时没有正确的返回
[修改描述]
增加idle状态表示未运行状态
[影响范围]
媒体
[测试建议]
[备注]

66.
[Bug][股票][Modified]修复股票成交量显示错误
[问题来源]
Fixes AIOSPUBLIC-4939
[根本原因]
单位不同，咱们数据返回的单位是手，一手等于100股
[修改描述]
数据放大100倍
[影响范围]
股票
[测试建议]
[备注]

67.
[Bug][股票][Modified]修复股票成交量显示错误
[问题来源]
Fixes AIOSPUBLIC-4939
[根本原因]
单位不同，咱们数据返回的单位是手，一手等于100股
[修改描述]
数据放大100倍
[影响范围]
股票
[测试建议]
[备注]

68.
[Bug][唤醒][Modified]保存动态设置的阈值
[问题来源]
普方达动态设置阈值灵敏度保存
[根本原因]
先设置灵敏度，再设置主唤醒，快捷唤醒未生效
[修改描述]
保存灵敏度设置
[影响范围]
唤醒
[测试建议]
[备注]

69.
[Bug][导航][Modified]地图界面，导航状态下添加途径点，查询天气等。adapter界面出现后闪退
[问题来源]
Fixes GAODE-213
[根本原因]
由保存地图类型引起重复查询高德状态引起
[修改描述]
保存地图去掉循环设置地图类型
[影响范围]
[测试建议]
[备注]

70.
commit 21fbd97c3cccbbdbd0dfecb4815d78625f19af29
Merge: 5dfb62a 06b64ea
Author: qinglong.wan <qinglong.wan@aispeech.com>
Date:   Tue Jun 20 14:59:28 2017 +0800
71.
[Feature][唤醒][Added]增加动态阈值设置
[需求来源]
客户直接需求
[实现方案]
动态设置阈值百分比
[影响范围]
唤醒相关
[测试建议]
[备注]

72.
[Improve][导航][Modified]高德定制版普方达分支合入主版本
[需求来源]
普方达分支BUG修改合入主版本
[改进方案]
BUG修复若干
[影响范围]
[测试建议]
[备注]

73.
# Conflicts:
#	app/aios-adapter/src/main/java/com/aispeech/aios/adapter/node/NavigationNode.java
#	app/aios-adapter/src/main/java/com/aispeech/aios/adapter/receiver/MapReceiver.java
commit d76bed4e2793f984d60fc484b7e87f7b7f651595
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Jun 15 14:58:15 2017 +0800
公版兼容普方达序列号授权
commit 656a65c28c8ddddfa3c257fc5c5335c37738b40d
Merge: a71abf2 a4e8578
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Jun 15 14:23:59 2017 +0800
74.
[bug][report][fix]修复非高德唤醒界面下上报事件与继续导航事件的冲突（GAODE-203）
[问题来源]
Fixes GAODE-203
[根本原因]
1、打开高德地图的过程中，主意菜单消失，上报事件被取消，导致菜单没有退出
2、高德地图打开地图时，高德会发送继续导航的广播请求。
[修改描述]
1、上报事件过程中，不处理继续导航的广播请求，上报优先。
2、休眠时，不取消上报事件 。
[影响范围]
上报
继续导航
[测试建议]
[备注]

75.
[Bug][Interface][Fix]修复语音启动每次都会调用sdk接口onAIOSRebooted
[问题来源]
Fixes AIOSPUBLIC-4351
[根本原因] 内核每次启动时首先都会出现授权失败情况 , 导致之前判断逻辑可能存在缺陷 目前只处理android层逻辑优化,内核授权失败的问题需要内核排查. 之前逻辑: 初始化消息链：kernel.ready -> adapter.nodes.ready -> third.nodes.ready(备用，暂不发送) 正常启动时，发送kernel.ready的时机一定会比GlobalHawk进入watch状态的时机早 目前测试: in aios-3.2 first time auth almost failed (i don't know why) and the kernel.ready usually publish later than nodes ready so before globalHawk status change to watch we may checkup the auth result
[修改描述]
在globalHawk 状态切换到 watch 前判断授权状态,直到授权成功后才切换到watch状态
[影响范围]
[测试建议]
[备注]

76.
[Bug][Interface][Fix]修复语音启动每次都会调用sdk接口onAIOSRebooted
[问题来源]
https://jira.spetechcular.com/jira/browse/AIOSPUBLIC-4351
[根本原因]
内核每次启动时首先都会出现授权失败情况 , 导致之前判断逻辑可能存在缺陷
目前只处理android层逻辑优化,内核授权失败的问题需要内核排查.
之前逻辑:
初始化消息链：kernel.ready -> adapter.nodes.ready -> third.nodes.ready(备用，暂不发送)
正常启动时，发送kernel.ready的时机一定会比GlobalHawk进入watch状态的时机早
目前测试:
in aios-3.2 first time auth almost failed (i don't know why)
and the kernel.ready usually publish later than nodes ready
so
before globalHawk status change to watch we may checkup the auth result
[修改描述]
在globalHawk 状态切换到 watch 前判断授权状态,直到授权成功后才切换到watch状态
[影响范围]
aios-release-3.2

77.
[bug][automap][fix]模拟上报不需要确认、上报时无网络处理、超时未上报时关闭上报界面
[需求来源]
https://jira.spetechcular.com/jira/browse/GAODE-183
https://jira.spetechcular.com/jira/browse/GAODE-178
https://jira.spetechcular.com/jira/browse/GAODE-174
[实现方案]
模拟上报不需要确认
上报时无网络处理
超时未上报时，监听asleep状态，关闭上报界面
[影响范围]
事件上报
[测试建议]
无
[备注]

78.
[bug][automap][fix] 修复搜索POI高德提示找不到目的地的问题
[问题来源]
https://jira.spetechcular.com/jira/browse/AIOSPUBLIC-4572
[根本原因]
1、高德的相关服务没有启动
2、高德路径规划的数据没有初始化
[修改描述]
1、主动启动服务
2、发起一次搜索POI行为，进行初始化
[影响范围]
[测试建议]
首先刷机使用时，高德地图初始化需要1分钟左右
[备注]

79.
[Feature][导航][Added]主动查询高德导航状态并保存途经点信息
[需求来源]
高德定制版增加导航状态主动查询
[实现方案]
增加导航状态主动查询并保存途经点信息
[影响范围]
增加/删除途经点
[测试建议]
打开高德地图，开始导航，再重启语音，待语音重启完毕，是否能正常增删途径点
[备注]

80.
[Bug][Adapter][Modified]Adapter全局异常处理
[问题来源]
Fixes AIOSPUBLIC-4387
[根本原因]
Adapter未增加全局异常处理
[修改描述]
Adapter增加全局异常处理
[影响范围]
[测试建议]
[备注]

81.
[Bug][导航][Modified]修复手动点击继续导航后，续航对话框消失语音不退出BUG
[问题来源]
手动点击继续导航后，续航对话框消失语音不退出
[根本原因]
没有调用退出语音
[修改描述]
此时调用语音退出
[影响范围]
继续导航
[测试建议]
[备注]

82.
[Feature][导航][Added]高德地图事件上报
[需求来源]
Resolves GAODE-169
[实现方案]
根据需求实现高德地图事件上报
[影响范围]
导航
[测试建议]
[备注]

83.
[Bug][BusClient][Modified]onCall执行某操作时报错无结果返回进入死循环
[问题来源]
Fixes AIOSPUBLIC-4031
[根本原因]
当onCall执行某操作时报错了，后续没有返回结果给BusClient，从而导致进入死循环
[修改描述]
BusClient在onCall时进行异常捕获
[影响范围] 执行出错后一直发相同rpc消息下来，可能导致机器卡死，adapter起不来等
[测试建议]
在jira单中体现
[备注]
无

84.
[Bug][导航][Modified]导航中查询我的位置会取消导航
[问题来源]
Fixes AIOSPUBLIC-4150
[根本原因]
导航时“查看我的位置”，地图会回到主界面，取消了导航
[修改描述]
当地图在后台时，直接把地图调到前台； 当地图未打开时，才打开地图
[影响范围]
导航时直接命令“查看我的位置”
[测试建议]
导航时直接命令“查看我的位置”，地图打开之后，导航不会被取消
[备注]

85.
[Bug][微信][Modified]微信偶现 ”我要发微信“  界面起不来
[问题来源]
Fixes AIOSPUBLIC-4026
[根本原因]
命令“我要发微信”调起界面判断前后台有误
[修改描述]
微信未打开或在后台  打开微信至前台
[影响范围]
微信
[测试建议]
”我要发微信“  微信界面是否正常
[备注]

86.
[Bug][微信][Modified]更新新疆客户微信登不上host变化问题
[问题来源]
Fixes AIOSPUBLIC-3855
[根本原因]
新疆微信服务器变更
[修改描述]
增加新疆客户微信host
[影响范围]
微信
[测试建议]
新疆客户微信正常登陆
[备注]

87.
[Bug][导航][Modified]修复正在导航时打开地图会取消导航
[问题来源]
Fixes AIOSPUBLIC-4150
[根本原因]
导航时说打开地图，回到主图，取消了导航
[修改描述]
导航时，地图在后台则打开，地图未打开则打开地图
[影响范围]
导航时打开地图操作
[测试建议]
导航时说打开地图，导航是否正常
[备注]

88.
[Bug][导航][Modified]附近领域美食、酒店可播电话配置
[问题来源]
附近领域美食、酒店可播电话配置
[根本原因]
附近领域电话配置有误
[修改描述]
aios-adapter/src/main/assets/configs/autolite.xml配置文件中autolite_nearby_phone false  ->  true
[影响范围]
附近领域美食酒店电话
[测试建议]
附近领域美食酒店有电话时是否能播电话
[备注]

89.
[Bug][UI][Modified]修复来电、限行、路况界面显示错误
[问题来源]
Fixes GAODE-161 GAODE-159 GAODE-162
[根本原因]
UI状态错乱引起
[修改描述]
重新整理UI状态，来电时消UI、限行配置文件设置为true、导航时播报路况
[影响范围]
导航中UI界面的展示
[测试建议]
[备注]

90.
[Bug][UI][Modified]修复导航时快捷唤醒无确认框
[问题来源]
Fixes GAODE-135
[根本原因]
DismissWindow 移除消息引起，目前不移除其他消息
[修改描述]
DismissWindow 移除消息引起，目前不移除其他消息
[影响范围]
导航中UI界面的展示
[测试建议]
[备注]

91.
[Bug][UI][Modified]设置界面切换失败
[问题来源]
无
[根本原因]
声音切换时，设置界面重新保存数据引起界面重新切换
[修改描述]
声音切换时，设置界面重新保存数据引起界面重新切换，此时加一个flag不切换设置界面
[影响范围]
[测试建议]
[备注]

92.
[Bug][导航][Modified]修复导航中重启机子，重置导航状态
[问题来源]
Fixes GAODE-157
[根本原因]
导航过程中重启机子，未重置导航状态
[修改描述]
导航过程中重启机子，恢复导航状态
[影响范围]
导航状态相关
[测试建议]
[备注]

93.
[Bug][导航][Modified]更新高德文档以及修复BUG
[问题来源]
更新高德文档，增加PoiBean的dst_name字段；
Fixes GAODE-152 GAODE-154 GAODE-157
[根本原因]
1、高德导航状态通知不及时
2、切换声音失效是由3.3新帮助界面引起
3、配合内核增加POIBean缺少的dst_name字段
[修改描述]
1、状态通知不对时加上容错处理
2、切换声音时保存起来并更新
3、增加PoiBean的dst_name字段
[影响范围]
[测试建议]
[备注]

94.
[Improve][定位][Modified]高德新SDK替换
[需求来源]
高德新SDK更新
[改进方案]
AMap_Location_v2.3.0_20160112.jar -> AMap_Location_V3.3.0_20170118.jar
AMap_Search_V3.2.1_20160308.jar   -> AMap_Search_V5.0.0_20170309.jar
Android_AMap_2.5.1.20150827.jar    -> Android_Map3D_SDK_V5.0.0_20170311.jar
[影响范围]
定位、搜索
[测试建议]
[备注]

95.
[Improve][定位][Modified]高德授权key打印
[需求来源]
高德授权失败
[改进方案]
修改高德授权key日志打印等级e,方便定位授权问题
[影响范围]
定位
[测试建议]
[备注]

96.
[Feature][定位][Modified]定位优化
[需求来源]
路测定位失败
[实现方案]
优化设置高德key有可能失败，授权失败时重新再次授权
[影响范围]
定位
[测试建议]
[备注]

97.
[Feature][导航][Modified]定制版界面展示以及操作优化
[需求来源]
产品郭一明
[实现方案]
发微信时界面展示配置以及手动点击设置家/公司位置播报
[影响范围]
发微信时界面消失、手动点击设置家/公司位置时正确播报
[测试建议]
[备注]

98.
[Feature][导航][Modified]自动全览图展示时间修改
[需求来源]
产品郭一明
[实现方案]
自动全览图由之前的3s改成5s
[影响范围]
开始导航之后自动全程概览
[测试建议]
[备注]

99.
[Bug][导航][Modified]界面显示优化
[问题来源]
深度定制界面显示优化
[根本原因]
未重置高德前后台状态以及POI搜索超时时间稍短
[修改描述]
增加高德前后台状态重置以及增加POI搜索超时时间
[影响范围]
唤醒之后界面展示以及POI搜索超时时高德地图界面展示情况
[测试建议]
[备注]

100.
[Improve][导航][Modified]高德定制版代码逻辑优化
[需求来源]
高德定制版代码逻辑优化
[改进方案]
高德定制版代码逻辑优化
[影响范围]
[测试建议]
[备注]

101.
[Feature][导航][Modified]沿途搜索增加经过POI播报
[需求来源]
沿途搜索增加经过POI播报
[实现方案]
沿途搜索增加经过POI播报
[影响范围]
沿途搜索时途经点播报
[测试建议]
[备注]

102.
[Bug][导航][Modified]路况查询播报英文
[问题来源]
FIX GAODE-125
[根本原因]
高德异常引起
[修改描述]
增加路况查询异常处理
[影响范围]
路况查询播报
[测试建议]
[备注]

103.
[Feature][导航][Modified]优化代码(修复搜索时界面不显示、算路失败多次播报、上下页识别时退出UI)
[需求来源]
优化代码(修复搜索时界面不显示、算路失败多次播报、上下页识别时退出UI)
[实现方案]
增加搜索界面展示时判断、算路失败判断、识别时不做UI处理
[影响范围]
[测试建议]
[备注]

104.
[Bug][导航][Modified]修改算路失败播报
[问题来源]
算路失败多次播报
[根本原因]
修改算路失败播报
[修改描述]
修改算路失败播报
[影响范围]
[测试建议]
[备注]

105.
[Improve][导航][Modified]更新内核以及部分日志打印
[需求来源]
无
[改进方案]
更新内核以及部分日志打印
[影响范围]
[测试建议]
[备注]

106.
[Improve][导航][Modified]地图搜索路径规划优化
[需求来源]
地图搜索路径规划优化
[改进方案]
修改地图超时时间以及路线规划播报间隔处理
[影响范围]
搜索超时以及路径规划失败播报
[测试建议]
[备注]

107.
[Bug][导航][Modified]路径规划开关
[问题来源]
路径规划开关
[根本原因]
路径规划开关默认值enable
[修改描述]
路径规划开关默认开启
[影响范围]
路径规划是否第一次生效
[测试建议]
[备注]

108.
[Improve][导航][Modified]小悬浮窗退出优化
[需求来源]
Resolves GAODE-111
[改进方案]
退出之前重置一下layoutparams
[影响范围]
偶尔出现返回按键无效
[测试建议]
[备注]

109.
[Bug][导航][Modified]高德搜索结果数量过大
[问题来源]
Fixes GAODE-102
[根本原因]
高德搜索结果数量过大
[修改描述]
返回数据量过大则只取前面的数据
[影响范围]
[测试建议]
测试过程中，是否还会发现搜索结果个数大于10
[备注]

110.
[Feature][导航][Modified]小悬浮窗状态优化
[需求来源]
小悬浮窗状态优化
[实现方案]
根据高德状态优化小悬浮窗
[影响范围]
导航小悬浮窗
[测试建议]
[备注]

111.
[Bug][导航][Modified]导航播报
[问题来源]
Fixes GAODE-106 GAODE-109
[根本原因]
优化播报逻辑
[修改描述]
优化播报逻辑
[影响范围]
导航去某地，继续导航
[测试建议]
[备注]

112.
[Bug][导航][Modified]UI界面展示优化
[问题来源]
Fixes GAODE-68 GAODE-98 GAODE-103
[根本原因]
UI交互杂乱
[修改描述]
UI界面展示优化
[影响范围]
语音交互小悬浮窗的状态
[测试建议]
[备注]

113.
[Bug][导航][Modified]地图内语音唤醒，会闪出话筒图标
[问题来源]
Fixes GAODE-68
[根本原因]
oneshot开始后vad状态引起
[修改描述]
oneshot开关开启且高德在前台第一次语音唤醒后 vad idle 状态第一次不进行通知
[影响范围]
语音唤醒图标状态
[测试建议]
[备注]

114.
[Improve][导航][Modified]删除途经点优化
[需求来源]
删除途经点优化
[改进方案]
以数组方式传输数据
[影响范围]
删除途经点
[测试建议]
[备注]

115.
[Bug][导航][Modified]沿途搜索、途径点替换不成功
[问题来源]
Fixes GAODE-90
Fixes GAODE-97
[根本原因]
旧途径点未删除
[修改描述]
设置途径点时先删除途径点
[影响范围]
导航途径点、沿途
[测试建议]
正常导航
[备注]

116.
[Bug][导航][Modified]导航回家不执行导航
[问题来源]
Fixes GAODE-96
[根本原因]
无路径规划时导航时判断错误
[修改描述]
增加正确判断
[影响范围]
无路径规划时导航回家
[测试建议]
[备注]

117.
[Bug][导航][Modified]导航去不支持的地点，退出语音交互
[问题来源]
Fixes GAODE-93
[根本原因]
导航去不支持的地点，未退出语音交互引起
[修改描述]
导航去不支持的地点，退出语音交互
[影响范围]
路径规划之后的导航
[测试建议]
开启路径规划开关，导航去台湾等，退出交互并播报语音
[备注]

118.
[Improve][导航][Modified]路况界面消失优化
[需求来源]
路况界面消失优化
[改进方案]
路况界面消失优化
[影响范围]
路况查询
[测试建议]
路况查询之后正常交互
[备注]

119.
[Bug][导航][Modified]路况查询小悬浮窗消失、帮助界面展示
[问题来源]
Fixes GAODE-89
[根本原因]
路况查询时UI倒计时引起
[修改描述]
去掉路况时界面倒计时消UI
[影响范围]
路况查询
[测试建议]
路况查询之后正常交互
[备注]

120.
[Improve][导航][Modified]沿途搜索优化
[需求来源]
沿途搜索优化
[改进方案]
沿途搜索优化
[影响范围]
导航沿途搜索
[测试建议]
[备注]

121.
[Improve][导航][Added]路径规划开关
[需求来源]
增加路径规划开关
[改进方案]
增加路径规划开关
[影响范围]
导航、路径规划
[测试建议]
导航以及路径规划相关
[备注]

122.
[Improve][稳定性][Added]合入aios3.2的有关nnr的buclient及测试代码
[需求来源]
产品需求，合入稳定性优化代码
[改进方案]
合入3.2已有的稳定性优化代码
[影响范围]
bc.call的调用，如遇非法超时会报nnr
[测试建议]
请跑nnr相关用例
[备注]
暂无

123.
commit 7d5ad76119d47144ace2f9cca1b0ac04b3998cc8
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Mar 6 10:46:55 2017 +0800
去除3d模式
commit a9e47e81bc708f8e6cb6098e81ee637ac049cea7
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Mon Mar 6 10:30:58 2017 +0800
修复小悬浮显示在主页问题
commit 786ce09e815b2fdb32d286f1e30ab28c488ede14
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 20:13:47 2017 +0800
发微信时多个联系人界面展示
commit 3f973f8708e6eaf478ab37006aa82ab63e45ffb8
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 20:01:56 2017 +0800
更新内核以及路径规划小悬浮窗
commit 9605408253176bf523d38ffa14d1b0ac9bff907b
Merge: 7dde97d 2c3a28d
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 19:21:30 2017 +0800
124.
commit 7dde97d685c579490e6f261a1ac1db1c601fa625
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 19:19:51 2017 +0800
修复上下一页无响应
commit 93f67d380aec4d869ba882fea42ec5c96d137b00
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 19:07:58 2017 +0800
修复确认悬浮窗，退出比较慢的问题
commit 2c3a28d16a1fc4759be384e7f4088063f7e247ac
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Fri Mar 3 17:01:50 2017 +0800
修复天气股票等查询完后悬浮框显示异常问题
commit 18c44a4ac63b1b5994ec3950c18197b2b4effae4
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 16:27:11 2017 +0800
快捷唤醒显示确认悬浮窗
commit 8dee12d6a557ad9d2f2f7f826344dc4dce19a949
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Fri Mar 3 16:03:31 2017 +0800
tts播报完恢复为唤醒图标
commit cb878af046a2b4e629edd28bf949a24549b94573
Merge: 5736069 6e425b4
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Fri Mar 3 15:27:42 2017 +0800
125.
commit 57360695686408b3297fcfd94ec7e1308baf9546
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Fri Mar 3 15:26:33 2017 +0800
修复路径规划时悬浮框消失bug
commit 6e425b48a90b343fc7457d53b10c4994361d7c9e
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 14:09:30 2017 +0800
提交内核，点击mic界面消失bug,途经点和终点相同时bug
commit 3e3d29dc936cb6c3b2ccdcb8d790013cea2ac202
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 11:48:08 2017 +0800
小修改“去某地，语音界面，手动点击，直接进入导航。
commit f425aee0faad8dfa68ef4b40f610f2a2e54413e4
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Mar 3 10:04:12 2017 +0800
沿途搜索距离已修改
commit b464f3615b6e3ba656f61b093f546530dd92952f
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 17:53:05 2017 +0800
更新搜索界面展示策略
commit 81ffdeb01d6323514635a914923531cbc5706262
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 16:50:57 2017 +0800
更新内核
commit 83df3587d95b8d1a21ec2e451fc667c810c78b7f
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 14:18:47 2017 +0800
电话号码没有时传空字符串
commit 85d1f4a1cc9ad74217182f64b6b9fbaef769b0ec
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 14:08:51 2017 +0800
有多个停车场时的提醒，内核没做好，目前不传说法给内核
commit 97b35f9bd9013b369ecb8811b54ff1f9d7a6b647
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 11:25:32 2017 +0800
整理代码3
commit 77a29a7c4cb1a3e7c399bb6c02d3d9089304ff5e
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 11:14:19 2017 +0800
整理代码2
commit b575322a619f508d79f54201aa818cb68b9391f1
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Mar 2 10:32:52 2017 +0800
整理代码
commit c83ec24878f86a2e257fb1c28876fe3b40659949
Merge: 0ec1ef8 019e0d9
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Mar 1 17:49:35 2017 +0800
126.
commit 0ec1ef8f9e8e777d6562c5743c664c1206f9eaec
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Mar 1 17:49:15 2017 +0800
完善删除途经点功能
commit 019e0d9fe4a912838aa27f473208c743fc6ccc8c
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 17:10:52 2017 +0800
保存终点信息
commit 814a8b1fc7863854069cbe9945739d3b9af13766
Merge: 734d55c 0e3f7fc
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Mar 1 16:43:51 2017 +0800
127.
commit 734d55c251bcceb28c7f816bc9705a9100a744c0
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Mar 1 16:43:23 2017 +0800
收到继续导航等通知时显示悬浮框
commit 0e3f7fc76be0a46ad67eab519364cee191d9c6df
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 16:17:37 2017 +0800
FIX  继续导航提示时，说“确定”“继续”无效
commit 428cce04b2bfff5449487618d7e1053fcf3fbb3d
Merge: 1326d02 39434ea
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 15:07:27 2017 +0800
128.
commit 1326d027c0b023dcd748464f1c1cb87c4492a984
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 15:07:02 2017 +0800
纯广播模拟高德提醒事件
commit 39434ea93443003484a195e7dc02522fded67dea
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Mar 1 14:51:49 2017 +0800
完善UI
commit abb92078f9c76f1354990774ebc712a83949f246
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 12:05:45 2017 +0800
主动获取高德状态
commit 24ae96bcb4b727ddf6ba1e26f63efdb78218a97c
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 10:58:17 2017 +0800
修复查询还有多远，不足一分钟，提示错误问题。
commit 8f94db4de0bd39d2842411e8124b13637e694007
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Mar 1 10:55:48 2017 +0800
完善回家去公司提醒进入路径规划
commit adce7d8b3742f45f63972a58414e8ab22c12aec7
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 21:19:56 2017 +0800
完善沿途搜索
commit 3b5e57edb9a3fe15dd31d1df6b653c1e12895fec
Merge: 2e9ec9c 6ce809b
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 20:52:35 2017 +0800
129.
commit 2e9ec9c88a78b9047bf7708ee50d647e8d4aad4e
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 20:52:05 2017 +0800
完善沿途搜索
commit 6ce809b4f8b4e6dc7e3b23b7834f877b0479bb24
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 28 18:53:12 2017 +0800
增加广播模拟[更优路线提醒、回家提醒]
commit 4ce4bf74696d5b61cd32510c5b63fa01572ca883
Merge: f0ccb32 0f81f06
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 28 18:05:45 2017 +0800
130.
commit f0ccb32831760aa6a7017671838e48081887d885
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 28 18:04:07 2017 +0800
小修改
commit 0f81f0604917ed0f011e7bbd78e10437cadb120c
Merge: e45a32f fcbd948
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 17:34:45 2017 +0800
131.
commit e45a32f22c38b0982cbac5f0b997c7f2648815c4
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 17:34:28 2017 +0800
完善添加途经点
commit fcbd948254703e845036a68c66b89f27f21f318b
Merge: 4d2e3b2 71bb0f8
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 28 16:52:09 2017 +0800
132.
commit 4d2e3b2744ae16efa1d9cdfd594f0e0eccec7aa3
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 28 16:50:33 2017 +0800
完善路况查询
commit 71bb0f8965bc0f20cb6901496d608aa3fc203d85
Merge: 0d3f459 1ca178d
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 11:21:53 2017 +0800
merge
commit 0d3f4599704f0d97e8aad0170b922b86c0b09f09
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 28 11:18:33 2017 +0800
完善沿途搜索以及修改Ui细节
commit 1ca178d3f324c8b715d18b60c3addb5d43fe7417
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 17:45:04 2017 +0800
语音焦点广播封装
commit 414d9dd52d8fbb2cb27488564c2ad22e1d605103
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 14:23:39 2017 +0800
修复查询还有多久，不足一分钟，提示错误问题。
commit 2d0b70f99e16b30b933a93005302f1ff450fefde
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 11:57:53 2017 +0800
关闭导航无响应，去掉退出框判断
commit 8f0e84abd518d43b2343968497db23a66c3bf211
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 11:10:07 2017 +0800
地图退出退出语音
commit 899321baf1dee31dfdcc190fa4d9a2b87db1d7b0
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 10:14:52 2017 +0800
沿途搜索新接口预留，恢复代码
commit 6e725b3746bf862300c114df9f76b044b6d3e337
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 09:56:42 2017 +0800
沿途搜索新接口预留
commit e7db5c3e3e9128a052a4c15c3ff064cf203ce085
Merge: 44dad39 41de8b9
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 27 09:51:04 2017 +0800
133.
commit 41de8b9af6610c035d75386881e072bb62361751
Author: yinan.qin <yinan.qin@aispeech.com>
Date:   Fri Feb 24 18:16:11 2017 +0800
高德定制版堆代码
需求来源：
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL
commit c8c9fee2161d9c4f9e10d7a2a780c88e0016dc28
Merge: f080bdf 4aad32d
Author: yinan.qin <yinan.qin@aispeech.com>
Date:   Fri Feb 24 18:14:20 2017 +0800
134.
高德定制版堆代码
需求来源：回家、回公司
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL

135.
commit 3d13ee0fd1ca2fccdc18ef742b72a543cc7175a0
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 23 17:26:59 2017 +0800
沿途搜索并路径规划
commit fd583007863437bac309c75ba340911a66b89a83
Merge: e5b645f 98eada7
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 23 16:23:58 2017 +0800
136.
高德定制版堆代码
需求来源：更优路线
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL
Closes #170223

137.
高德定制版堆代码
需求来源：
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL

138.
commit f851464390dcea2064dd13f41dc815c37c752ff9
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 23 12:12:39 2017 +0800
完善开始导航代码
commit 4884dd8f048a99cfbbdaf7a2e895844810a74d14
Merge: 9e6c257 0a71a42
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 23 12:03:30 2017 +0800
139.
commit 9e6c257996038c201c5c348d6cbb1d43cc87835a
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 23 11:56:38 2017 +0800
小修改
commit 0a71a426e34a6adc54942944b373a4720260fe2f
Merge: 7f08466 d8b6e09
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 23 11:45:48 2017 +0800
140.
commit 7f08466f2d886583eb73fc52fe87a4f964110af9
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 23 11:44:56 2017 +0800
完善路径规划
commit d8b6e09fd1659d5242405363e1ef52aed8384981
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 18:44:27 2017 +0800
导航中偏好小修改
commit 4ea7800c299e6df6517718cece0bf5701eda4a39
Merge: bd72539 8eaf1dc
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 18:39:24 2017 +0800
141.
commit bd72539e6711f653e8c083b4f77e0493b2edd555
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 18:38:59 2017 +0800
导航中增加偏好
commit 8eaf1dca625de74287a4a76a741da4c40cda9169
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 18:22:48 2017 +0800
停车场个数动态设置
commit d4c1bf755606ead2f6aee6426ff665dd7f7248b2
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 18:20:43 2017 +0800
增加路径选择接口，路径规划时隐藏悬浮框
commit 8991e584b973fd57a7aa4646d41aee60a13a4bd4
Merge: 975dc4e 0382730
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 17:37:32 2017 +0800
142.
commit 975dc4e7e919cb1f09bf1496267af1f24945d665
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 17:36:49 2017 +0800
初步联调路径规划
commit 0382730d9f535d9a94426e0d4055a48f8381bba6
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 17:30:06 2017 +0800
poi搜索上下页操作
commit 8dc12c4c715cfcb37525fb8178cd24bba6685d36
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 16:50:03 2017 +0800
import head
commit 427795afef423605052d8b11e67fd112666d7ffd
Merge: 14917c3 a1acf30
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 16:35:08 2017 +0800
143.
高德定制版堆代码
需求来源：
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL
Closes #170222

144.
commit 67f4b931bd6e5ecc477da311685cb48717f9cf8a
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 16:28:22 2017 +0800
1、天气、路况、现行、电话UI展示
2、导航时设置公司/家位置在应用外搜索
commit 57adf59bebd60437c253f700936b474639a4851d
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 22 16:18:58 2017 +0800
1、天气、路况、现行、电话UI展示
2、导航时设置公司/家位置在应用外搜索
commit 519d222b733254bc7be9d82a3373f17fd4295a71
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 15:03:48 2017 +0800
保存悬浮框坐标
commit f8b7a35ae84c1696dc1e13bb99a750f15105eb66
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 22 14:41:03 2017 +0800
完善UI效果
commit c6c0fe98fe4bfbfed7e0f560ab5e213dcf20ac11
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 21 19:50:34 2017 +0800
更新内核
commit f36e6edeb5da7d054df3979eee919eda52cf0386
Merge: 290332c 9eaba66
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 21 19:29:59 2017 +0800
145.
高德定制版堆代码
需求来源：
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL

146.
commit 14bf8ceb9bd37a304624aa560b8d17256a88143c
Merge: 931e8d7 966df02
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 21 17:43:19 2017 +0800
147.
# Conflicts:
#	app/aios-adapter/src/main/java/com/aispeech/aios/adapter/util/map/gaode/AmapProperty.java
commit 1022a64895449f00e635552f6442a7490ea68ba8
Merge: 6de33a8 966df02
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 21 17:17:45 2017 +0800
merge
commit 6de33a85cde0993fd866728d61738823417f5674
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Tue Feb 21 17:02:53 2017 +0800
完善动画效果
commit 931e8d7e6b0fff9dd16ddab0a0d2f15e670575d7
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 21 17:00:37 2017 +0800
MapReceiver稍作整理
commit 966df028e2ac3d16161d9db3a7b265f423724757
Merge: 7cd69f7 a2c3bc2
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 21 16:58:40 2017 +0800
148.
高德定制版堆代码
需求来源：
修改描述：ALL
影响范围：ALL
测试建议：NULL
备注：NULL

149.
commit 1b830228542ea9e26f8d6951d9a8b4151adbe77b
Author: ping.yang <ping.yang@aispeech.com>
Date:   Fri Feb 17 11:12:51 2017 +0800
1、优化附近搜索
2、增加高德界面在前后台时界面展示(暂时)
commit 63b39e82ae421ec5357d366a0ed24a97f88ea681
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Fri Feb 17 09:51:57 2017 +0800
点击悬浮框启动aios，增加是否有导航栏的判断
commit efb5e134f1a8f6ee59a362beb15e4195565dae45
Merge: c7425d4 acaf271
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 18:34:10 2017 +0800
150.
commit c7425d4e9a71bea5d6320ea8359b1a0d4b2a2566
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 18:33:17 2017 +0800
add float ui click event
commit acaf27168cd7cc6009ba49d8d92e1efb45120537
Merge: 1246db5 c6ecd5e
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 16 18:20:20 2017 +0800
151.
commit 1246db5677d43935ae7708f7941b28d78a7abd5e
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 16 18:19:50 2017 +0800
语音上下页实际为高德上下屏，稍作修改
commit c6ecd5e3098ce155a0f56c7946d8a8a8fd39562d
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 17:12:15 2017 +0800
修复动画时显示未唤醒背景问题
commit 0929146abf7ae8d18350c42cb905eca2193cc608
Merge: fe279f8 ab99cc3
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 14:33:14 2017 +0800
152.
commit fe279f89fdb77ac647112b8962f46de42e0ad05c
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 14:32:37 2017 +0800
add amap mic anim
commit ab99cc390f39e919c7f8acbabd651ce3991fe40c
Merge: caf9a9f 4779771
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 16 12:35:05 2017 +0800
153.
commit caf9a9fe03ac6fa5e89a1ec3cdf3a4acaedfdf17
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 16 12:34:12 2017 +0800
根据搜索类型修复nearby结果不准确的BUG
commit 4779771710e090834a2d9f3f0154f764c6ee29ca
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 11:54:34 2017 +0800
悬浮框消失时退出服务
commit a7ba65d2aeec362183f9e2aee1932a1d9f58039c
Merge: e48392b 947c561
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 11:48:52 2017 +0800
154.
commit e48392b7637872f777506a40834cbc90c225ded3
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Thu Feb 16 11:48:16 2017 +0800
add amap float ui
commit 947c5618455c1460a22bd9396a03e0bc3d35a7ad
Merge: 1d6d587 47cbf89
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 16 09:53:15 2017 +0800
155.
commit 1d6d587b885bb8b6471adbcfc544a69416227471
Author: ping.yang <ping.yang@aispeech.com>
Date:   Thu Feb 16 09:52:49 2017 +0800
优化POI搜索部分，nearby
commit 47cbf899511773943927919d09ce580522c1b462
Merge: bbf1046 96a02e7
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 15 15:45:12 2017 +0800
156.
commit bbf10469c71222c4ef72426fc0367c52677bfd29
Author: pengfei.zhou <pengfei.zhou@aispeech.com>
Date:   Wed Feb 15 15:44:01 2017 +0800
update map receiver
commit 96a02e7249d1dcdf6191721afecc6a3e621eb758
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 15 15:29:24 2017 +0800
高德定制版地图第五次修改
增加POI前后台搜索
增加高德在前台搜索结果操作
增加部分高德界面操作通知
commit a368d17961d53c36191c72564d0c9f0c36e0381e
Author: ping.yang <ping.yang@aispeech.com>
Date:   Wed Feb 15 12:36:33 2017 +0800
高德定制版地图第四次修改
commit 520ecd64aea17405af99182d28a6c0e011b69d78
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 14 18:51:37 2017 +0800
高德定制版地图第三次修改
commit 76d9f19900684021b215b9869cbfa62571ff490a
Author: ping.yang <ping.yang@aispeech.com>
Date:   Tue Feb 14 16:54:55 2017 +0800
高德定制版地图第二次修改
commit c413067c5270e491641d1afbe82e3ee21dd0f9b9
Author: ping.yang <ping.yang@aispeech.com>
Date:   Mon Feb 13 18:40:00 2017 +0800
高德定制版地图第一次修改
commit f3961b99c5478a2a7ebc8cbb3dd6412571c63152
Author: qiang.wang1 <qiang.wang1@aispeech.com>
Date:   Fri Feb 10 12:17:37 2017 +0800
新增VersionChage.md模板用于版本号变更的merge request
commit fe992acd63232f757c6b7d1ad461570241a79c7a
Merge: 042e6fd 0951dd8
Author: rong.liu <rong.liu@aispeech.com>
Date:   Thu Feb 9 14:55:30 2017 +0800
157.
[Bug][电话][Modified]同步联系人失败
[问题来源]
https://spetechcular.com/jira/browse/AIOSZXCL-42
[根本原因]
new JSONArray(jsonArrayString).length()引起OOM
[修改描述]
去掉该判断，在上一层逻辑处理合法性
[影响范围]
联系人数据量比较大时，用AIOSContactDataNode、AIOSPhoneManager同步联系人失败。
[测试建议]
技术支持同事配合测试同事进行测试
[备注]

158.
[AIOS][BUS][DEBUG][Add]支持实时dump各节点信息
[需求来源]
新增"实时dump各节点信息"的特性
[实现方案]
1.bus.event新增"dump"事件
2.节点响应dump事件，并打印各自信息
PS：若功能节点需要打印更详细的业务信息，请重载dump函数
[影响范围]
无
[测试建议]
情景1（发布bus.event dump player）
1. 发布bus.event dump player
2. player打印出完整节点运行信息和节点业务信息（player节点已经通过重载dump函数实现了打印业务信息的目的）
情景2（发布bus.event dump all）
1. 发布bus.event dump all
2. 所有节点都会打印出各自的节点运行信息，重载了dump函数的节点都会打印出各自的节点业务信息
情景3（发送aios.intent.action.DUMPSYS广播）
1. 发送aios.intent.action.DUMPSYS广播
2. 所有节点都会打印出各自的节点运行信息，重载了dump函数的节点都会打印出各自的节点业务信息
[备注]dump player节点效果如下：
---------------------------------------------
DUMP OF CLIENT player:
running: true
runningErr: null
socket connect: true
socket bufsize: 65536
pending RPC: 0
pending Topic: 0
pending Timer: 1
subscribed Topics: [music.listen.songs.playmusic, aios.state, bus.event, shutup, phone.incomingcall.state, phone.outgoingcall.state, music.listen.songs.stopmusic, tts.speak.pcm]
DUMP OF NODE player:
thread state: busy.
stickyMessages: null.
state: idle
aiosState: asleep
phoneIncomingcallState: idle
phoneOutgoingcallState: idle
playerStream: 1
musicAudioFocus: 0
TTS_AudioTrack_Vol: 1.0
isTtsPlay: false
isTips: false
isMapMute: false
isWechatRecordMute: false
AIOS Speaking: false
TTS Speaking: false
Latest Tts Id: -1
---------------------------------------------

159.
[附近][Modified]恢复查附近10KM以外代码
[需求来源]
恢复查附近10KM以外代码
[改进方案]
[影响范围]
[测试建议]
[备注]

160.
[附近模块][Modified]修改搜索附近为10KM以外的结果
[问题来源]
搜索附近为10KM以外的结果
[根本原因]
queryNearby的searchDstAddr改变了搜索源地址
[修改描述]
去掉
[影响范围]
附近
[测试建议]
观察附近搜索结果
[备注]

--------
161.
[Bug][导航][Modified]打开识别。在POI列表有识别有唤醒
[问题来源]
Fixes AIOSPUBLIC-5265 AIOSPUBLIC-5472
[根本原因]
VST需求时关了识别，
[修改描述]
屏蔽相关代码
[影响范围]
POI列表选择
[测试建议]
POI列表选择时，可以听歌，可以快捷指令
[备注]

162.
[Bug][微信][Modified]发微信说“下一页"之后 语音识别关闭的问题
[问题来源]
Fixes AIOSPUBLIC-5393
[根本原因]
语音识别关闭
[修改描述]
不关闭
[影响范围]
[测试建议]
[备注]

163.
AIOSPUBLIC-5534
【3.3开路者】微信联系人选择界面，部分联系人识别不了

164.
[Bug][接口][Modified]FIX AIOSPUBLIC-5547 语音定制新旧接口测试，反馈主人我刚刚开小差了
[问题来源]
Fixes AIOSPUBLIC-5547
[根本原因]
空指针
[修改描述]
[影响范围]
[测试建议]
[备注]

165.
[Feature][合并][Modified]合并3.3开路者
[需求来源]
合并3.3开路者
[实现方案]
合并3.3开路者
[影响范围]
ALL
[测试建议]
全功能测试
[备注]

166.
[Bug][微信][Modified]bugfix
[问题来源]
翻代码的时候发现的
[根本原因]
完毕完毕，取消取消　在录音界面直接去调用应用层接口，如开启微信录音界面云端识别，会导致正常识别内不能识别结束．
[修改描述]
见代码
[影响范围]
我要
[测试建议]
无
[备注]
无

167.
bugfix & sds 提交
提交未合入的微信内容及sds.lub提交

168.
我要上报bug fix
将板牙的我要上报的代码合入3.3分支

169.
sds commit
sds.lub提交，修改了我要提交的归一化

170.
3.3 bug fix
3.3合入开路者分支后的bug修改，多次提交

171.
[Bug][附近][Modified]fix bug https://jira.spetechcular.com/jira/browse/GAODE-217
[问题来源]
https://jira.spetechcular.com/jira/browse/GAODE-217
[根本原因]
domain内部逻辑处理错误
[修改描述]
见修改
[影响范围]
附近领域未开启路径规划领域的时候
[测试建议]
无
[备注]
无


172.
[Bug][附近][Modified]fix bug https://jira.spetechcular.com/jira/browse/GAODE-217
[问题来源]
https://jira.spetechcular.com/jira/browse/GAODE-217
[根本原因]
domain内部逻辑处理错误
[修改描述]
见修改
[影响范围]
附近领域未开启路径规划领域的时候
[测试建议]
无
[备注]
无

173.
[Bug][附近][Modified]fix bug https://jira.spetechcular.com/jira/browse/GAODE-217
[问题来源]
https://jira.spetechcular.com/jira/browse/GAODE-217
[根本原因]
domain内部逻辑处理错误
[修改描述]
见修改
[影响范围]
附近领域未开启路径规划领域的时候
[测试建议]
无
[备注]
无

174.
[Bug][bug][Modified]修复 1 https://jira.spetechcular.com/jira/browse/AIOSPUBLIC-5260 2 https://jira.sp…
[问题来源]
1 https://jira.spetechcular.com/jira/browse/AIOSPUBLIC-5260
2 https://jira.spetechcular.com/jira/browse/AIL-564
[根本原因]
见jira单备注
[修改描述]
更新sds.lub
[影响范围]
如jira单
[测试建议]
无
[备注]
无
-----标题模板（请贴到标题后请删除）-----
commit title

175.
[Bug][分词][Modified]bugfix  AIOSPUBLIC-5265
[问题来源]
AIOSPUBLIC-5265
[根本原因]
该种场景下下,微信快捷唤醒词没有过滤
[修改描述]
该种场景下,只响应offer状态下的分词
[影响范围]
列表交互
[测试建议]
无
[备注]
无

176.
[Bug][本地识别][Modified]1 fix asr节点起不来 2 修复本地打断识别结果没有语义
[问题来源]
1 昨天提交合并代码多删除了gram中CMD_DEL_PASS_POI 导致asr节点起不来
2 昨天提交合并代码speech/init.lua代码因添加vst需求,没有同步完全导致打断识别结果没有语义
[根本原因]
如上
[修改描述]
补上
[影响范围]
asr
[测试建议]
无
[备注]
无

177.
同步doppelganger分支代码到高德定制分支

178.
[Feature][音乐电台][Added]Hl fix aiospublic 4172 3.2.x
[需求来源]
Resolves AIOSPUBLIC-4172
[实现方案]
播放音乐电台时没有考虑没有安装应用的情况
[影响范围]
音乐，FM
[测试建议]
按jira单测试


179.
[Feature][音乐电台][Added]Hl fix aiospublic 4172 3.2.x
[需求来源]
Resolves AIOSPUBLIC-4172
[实现方案]
播放音乐电台时没有考虑没有安装应用的情况
[影响范围]
音乐，FM
[测试建议]
按jira单测试

180.
[Feature][继续导航支持打断][Added]fix GAODE-143 继续导航无法打断
[需求来源]
Resolves GAODE-143
[实现方案]
见代码
[影响范围]
全范围
[测试建议]
1.按jira单复测

181.
[Feature][上报][Modified]fix GAODE-198
[需求来源]
Resolves GAODE-198
[实现方案]
在wakeup.command中处理快捷命令时假如对当前是否为mydomain==xnotification的判断，如果
是上报流程，则不响应
[影响范围]
wakeup.command
[测试建议]
涉及快捷唤醒的全功能测试
按jira单测试

182.
Dev master commonnotification 2th

183.
修复发送完微信时无法唤醒的问题
[问题来源]
AIOSPUBLIC-4226
AIOSPUBLIC-3966
AIOSPUBLIC-4141
GAODE-163
[根本原因]
wechat domain 清除唤醒打断时机出错
[修改描述]
将唤醒打断操作切顺序
[影响范围]
微信发送界面 唤醒操作
[测试建议]  发送微信的时 完毕完毕 取消取消 唤醒正常
[备注] 自测ok






184.
修复发送完微信时无法唤醒的问题
[问题来源]
AIOSPUBLIC-4226
AIOSPUBLIC-3966
AIOSPUBLIC-4141
GAODE-163
[根本原因]
wechat domain 清除唤醒打断时机出错
[修改描述]
将唤醒打断操作切顺序
[影响范围]
微信发送界面 唤醒操作
[测试建议]  发送微信的时 完毕完毕 取消取消 唤醒正常
[备注] 自测ok





185.
commit 4799d4c9c6a9575b8c2a168521fdd5e4992af1e9
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Mon Apr 24 18:01:44 2017 +0800
fixed if domain is navi then not jump to chat
commit d6f8bba28efecc95881b02301cbf7a4a60fa8441
Merge: 572dbaa 351fd39
Author: mingguo.hu <mingguo.hu@aispeech.com>
Date:   Mon Apr 24 16:11:37 2017 +0800
fix AIOSPUBLIC-4135
fix  AIOSPUBLIC-4135



186.
fix AIOSPUBLIC-4135
fix  AIOSPUBLIC-4135


187.
fix  AIOSPUBLIC-4132

188.
commit 941f298593b7331b2c3a383a7c2198d4d818b332
Author: jianli.liu <jianli.liu@aispeech.com>
Date:   Wed Mar 15 17:23:02 2017 +0800
0315版本提交
commit a9474e76e6501572c2a7dfc5e4302cf366de886f
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Wed Mar 15 11:02:30 2017 +0800
修改限行流程
commit 2ac7a45548160fc539ac07babbaba390c085a759
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Mar 14 10:07:21 2017 +0800
对齐代码
commit 33c065998dff12e384c389f4283c61b298007af9
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Mon Mar 13 21:13:17 2017 +0800
添加路径规划可配置
commit 8d666ee7af63b2a15320e2919ff20f5e6597b7be
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Fri Mar 10 15:02:59 2017 +0800
合入3.2稳定代码
commit 3814f645e802789f15f41827f343e0a4dc2b0ec2
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Mon Mar 6 21:11:45 2017 +0800
修复路径规划的bug
commit c4a1fa7e36830c685c22ab790a1f736d0161ed2f
Author: jianli.liu <jianli.liu@aispeech.com>
Date:   Fri Mar 3 18:24:25 2017 +0800
删除途经点bug
commit 38fb5838fcf1043721393a42a00122822854ca35
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Fri Mar 3 16:17:02 2017 +0800
修复在路径规划时说啦啦啦切到导航的问题
commit 073dd3ea0dabec8cc01a566d88226588e93f962a
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Thu Mar 2 16:20:51 2017 +0800
修改正确的导航流程
commit 9f228016bfae4955ded0080119f27a6f06e918c5
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Wed Mar 1 14:21:54 2017 +0800
修正设置家的位置是sds状态未清除
commit c072ebf3b9902841fe8ff4a7fbb5f42faddb6b7c
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Wed Mar 1 11:55:15 2017 +0800
添加路径规划倒计时
commit d7ae87dab05c13c704051789b02fd9f454bed488
Merge: b24d6fc b98d6ff
Author: jianli.liu <jianli.liu@aispeech.com>
Date:   Tue Feb 28 20:48:28 2017 +0800
commit b24d6fcd5a3a8e3291c51a93e35caee65cd0076b
Author: jianli.liu <jianli.liu@aispeech.com>
Date:   Tue Feb 28 20:47:46 2017 +0800
途经点的相关修改
commit b98d6ff23a60a4865e42ddf50a55a21876934e74
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Feb 28 16:24:36 2017 +0800
更新sds lub
commit 1066aa854231d75211ecc17c8dbea1053af61444
Author: jianli.liu <jianli.liu@aispeech.com>
Date:   Tue Feb 28 16:15:44 2017 +0800
修改途经点信息
commit 5b321f36c98fe8c9fa4da60a2bbdd0f93de7e53d
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Feb 28 11:52:07 2017 +0800
修正不能退出的问题
commit 8467e4eacb4150de9f0463b7a30028ce8cb8f99a
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Feb 28 11:23:36 2017 +0800
修改bug
commit 69eb947dab945dd6bca96d1135caac3ba9913bb3
Author: jianli.liu <jianli.liu@aispeech.com>
Date:   Mon Feb 27 10:04:06 2017 +0800
途经点相关代码添加
commit 6c5e8130fa9c0dc763617652205686eaad7ed450
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Fri Feb 24 17:00:48 2017 +0800
修改附近崩溃bug
commit 0b579d5a29025166177bbca656844bf6c867dfab
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Thu Feb 23 20:36:07 2017 +0800
导航回家也需添加路径规划
commit 074368f6c31efbbe6f0a9bca927240a9e9e250bd
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Thu Feb 23 19:58:01 2017 +0800
添加通知领域跳转至route
commit 8836d4a365a05eb85fdb2c6f698942c8a28b3d3a
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Thu Feb 23 10:17:32 2017 +0800
1.添加途径点个数接口2.添加同步蓝牙状态接口3.附近添加跳转至路径规划
commit e2b6b4d240618ef5a3c4ea6c0edda613bb009a42
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Wed Feb 22 15:21:14 2017 +0800
修改bug
commit 9ceec902c12ecb5fc2f6205a08f50daff0f49a0a
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Feb 21 14:33:10 2017 +0800
add route
commit 071b284d413f72e82aafe22be7f1c5e66cce193d
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Fri Feb 17 11:22:26 2017 +0800
添加导航回家支持当前位置和目的地说法
commit c25a74a2da89422d597e69caa288d70deabd7125
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Wed Feb 15 15:27:57 2017 +0800
优化代码
commit 737af6cc421a01083a4cd83c6e9c375c6212e81a
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Feb 14 18:46:49 2017 +0800
modify code
commit 6a7b7564e8b4f08e100f44110f3def0957db5e57
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Feb 14 10:15:06 2017 +0800
添加通知自定义确定取消说法
commit a881e2ba4eb45034aac273acb63add564b136261
Merge: f07b38d b5a465f
Author: weiqiao.zheng <weiqiao.zheng@aispeech.com>
Date:   Mon Feb 13 16:33:26 2017 +0800
[Bug][模块或功能][Added/Modified/Deleted]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

189.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

190.
[Bug][模块或功能][Added/Modified/Deleted]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

191.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

192.
[Bug][模块或功能][Added/Modified/Deleted]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

193.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

194.
[Bug][模块或功能][Added/Modified/Deleted]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

195.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

196.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

197.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

198.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

199.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

200.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

201.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

202.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

203.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

204.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

205.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

206.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

207.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

208.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

209.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

210.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

211.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

212.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

213.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

214.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

215.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

216.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

217.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

218.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

219.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

220.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

221.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

222.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

223.
[Bug]同步通讯录时占用内存占用增加很大;
[问题来源]
Fixes AIOSPUBLIC-2955
[根本原因]
联系人名字进行多音字扩展时，字符串拼接导致内存消耗过大；
[修改描述]
优化本地grammar对联系人与号码的格式写法;优化垃圾回收;修改commit的机制;将字符串拼接改为table拼接;
[影响范围]
影响联系人与号码的本地识别；优化了更新grammar文件时的内存消耗; 　
[测试建议]
按照jira case测试
[备注]
无

224.
[Bug][通知][Modified]修正通知领域数据被清除
[问题来源]
开发自提
[根本原因]
数据缓存被清楚
[修改描述]
在destroy时不清楚数据
[影响范围]
通知领域
[测试建议]
按正常测试流程测试
[备注]

225.
commit 476456aaa5c455ea9890879c4e7838f9ba194dd7
Author: qiang.wang1 <qiang.wang1@aispeech.com>
Date:   Fri Feb 10 14:18:31 2017 +0800
更新和添加 merge request 模板
commit 1c559565dee3482b56863376b80390a97e88911c
Merge: 55afc23 6d57bec
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Thu Feb 9 10:09:31 2017 +0800
commit 6d57bec7e134d7d918caad7bb47cb3a00ed5d8bb
Merge: 2302b15 0b95d6a
Author: li.li <li.li@aispeech.com>
Date:   Wed Feb 8 14:40:13 2017 +0800
[AIOS][BUS][DEBUG][Add]支持实时dump各节点信息
## Demand description:
新增"实时dump各节点信息"的特性
## Solution:
1.bus.event新增"dump"事件
2.client响应dump事件，并打印各自信息
PS：若各节点需要打印更详细的业务信息，只需在节点内部实现dump函数即可
---------------------------------------------
DUMP OF CLIENT: tts
running: true
pending RPC: 0
pending Topic: 0
pending Timer: 0
subscribed Topics: [bus.event keys.tts.res keys.tts.speechrate customize.tips keys.tts.param speak customize.tts keys.tts.volume ]
---------------------------------------------
---------------------------------------------
DUMP OF NODE: tts
state: idle
speechVolume: 50
speechrate: 0.85
ttsvoice: lin-zhi-ling
---------------------------------------------

226.
commit 2302b15c68d404d74c5eaced469745823a05106c
Author: weiqiao.zheng <weiqiao.zheng@aispeech.com>
Date:   Tue Feb 7 10:19:37 2017 +0800
oneshot remainning time update to 600ms

227.
R3.2 bugfix


228.
R3.2 bugfix

229.
commit 12b613d5943959d80de212e68c23d05996b03436
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Wed Jan 18 09:53:48 2017 +0800
wait 状态改变提前
commit fd51302c3e98d87f401787275987aa5da5539188
Merge: 12ee5dc a9c468f
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Tue Jan 17 10:19:04 2017 +0800
commit a9c468f0fa32df531fdf4d87b8ab6d38642ed206
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Mon Jan 16 16:41:13 2017 +0800
vad节点在判别只是唤醒词时,不抛vad.state end topic消息,只是唤醒
commit 4827c2304a58add7ac0594a2d46cc73e33234bf8
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Wed Jan 11 16:44:39 2017 +0800
tts update to 0.5.10
commit a90bc7ebb31cd85dc345828b12e9f816386e4e96
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Wed Jan 11 16:44:09 2017 +0800
tts update to 1.5.10.4
commit 12ee5dc53ba9d5f2107898607d1f0e353795e380
Merge: fc14e3e be6c66e
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Fri Jan 6 18:59:06 2017 +0800
commit be6c66e9387c6de2104f0ba45273cac685739b37
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Fri Jan 6 18:30:24 2017 +0800
tts update to 1.5.9.4 引用改成all_in_one 同时解决;合成成啊的问题
commit fc14e3eb6f8b40808eff3cac28739c445315d0c0
Merge: 4b364af 95d0691
Author: chunhua.zeng@aispeech.com <chunhua.zeng@aispeech.com>
Date:   Thu Jan 5 10:46:55 2017 +0800
commit 95d069118c68bb6847533ff790b573f4b67a018c
Merge: e5053a9 ff4364f
Author: shun.zhang <shun.zhang@aispeech.com>
Date:   Wed Jan 4 17:13:19 2017 +0800
[AIOS][Core][Server][Add]增加对request的死锁检查以防AIOS假死
## Demand description:
增加对request的死锁检查，消除节点间互call导致AIOS假死的隐患
## Solution:
bus server将request转发给被调用者之前，检查调用者和被调用者是否存在环形调用
## JIRA:
jira单号以及目前的状态，MR会自动与jira联动，状态请使用`Resolves`或`Closes`或`Fixes`, 如：
无

230.
增加Readme

231.
修改电话联系人name为空的bug

232.
commit b4ca2fbab097cce45b5e4b1252dd2ffa6a3284b5
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Thu Dec 29 09:17:29 2016 +0800
统一cntts.so 版本
commit 211f4d8c25a35b003463a9daf7785228482163e0
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Wed Dec 28 21:39:29 2016 +0800
update tts so out of array bound
commit c814b56e1ade4b50ac073721f71bcb911b1b84eb
Merge: e99ed68 2e7a903
Author: chunhua.zeng <chunhua.zeng@aispeech.com>
Date:   Wed Dec 28 18:34:41 2016 +0800
增加processor自动化测试代码

233.
修复trafficstate订阅消息的时序问题；修改phonecall的一个拼写错误

234.
Master vad speed up
1,补全vad.status sil ,在oneshot首次时,容易丢失vad.status sil状态
2,删除vad 内核层封装的调试日志
3,精简vad节点lua层实现,删除一些变量标记,删除vad.end vad.active这两个topic消息等

235.
添加音乐，听歌识曲，限行，电台case

236.
Wakeup 1.5.6

237.
commit 8650064a65f49ee070829915dcc923d157ce2913
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Fri Dec 16 14:51:53 2016 +0800
wakeup res update to 0.10.1
commit 9b53b8b3b4624bbbf9b5b5606f83e6b8ac642746
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Fri Dec 16 14:51:24 2016 +0800
wakeup version update to 1.5.5
commit a40a40cd20459b453d0e4d85adacc6414eb3f1af
Author: wolfliu <yanwu.liu@aispeech.com>
Date:   Fri Dec 16 10:44:53 2016 +0800
增加自动化测试工具
commit cedd2d1c1c09a17d24e4756b0bf94484e0a71663
Author: weiqiao.zheng <weiqiao.zheng@aispeech.com>
Date:   Thu Dec 15 21:49:19 2016 +0800
根据需求增加本地grammar的内容
commit e413444cfabe02688b399d31354cbf1a570058d4
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Thu Dec 15 14:43:18 2016 +0800
tts res update to 0.5.9
commit fc3ce381b1fc1fd83e08420d49f649bcbbe76f17
Author: chengya.zhu <chengya.zhu@aispeech.com>
Date:   Thu Dec 15 14:42:42 2016 +0800
tts update to 0.4.44
commit e47ad7bf1df99ed999436e7e2b736bae3c4ce579
Merge: 5981adc ce41291
Author: chunhua.zeng <chunhua.zeng@aispeech.com>
Date:   Thu Dec 15 10:41:40 2016 +0800
修复列表循环不是一个命令的问题

238.
添加快捷唤醒识别过滤

239.
修复远程调试时，出现的云端节点崩溃的问题

240.
修复本地命令和一些快捷唤醒bug

241.
sdslub提交

242.
导航新需求添加

243.
Fixbug musicadd

244.
Master vad wakeup update

245.
add chetouxiangshang

246.
修正代码错误

247.
1.加回返回主页和一些本地命令的修改

248.
修复断网情况下不能使用oneshot说本地命令

249.
添加漏合并yunos的快捷唤醒词，以及删除返回主页

250.
修正继续播放bug

251.
modify wakeup switch


[How to start] 
1. 当前版本唤醒词为 “你好小驰或者小驰你好”。
2. 如果有其他应用对接方面的问题，请联系aispeech的技术支持，谢谢！ 
