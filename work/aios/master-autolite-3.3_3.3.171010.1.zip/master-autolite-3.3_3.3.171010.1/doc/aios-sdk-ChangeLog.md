  ###AIOSForCarSDK - 3.3 release 版本更新日志
 a.主要更新：
 I.   核验后剔除AIOSStatusListener#onPlayerStatusChange回调的IDLE状态（实际并无IDLE状态）；
 II.  废弃AIOSFmListener#onSwitchChannel回调；
 III. 废弃AIOSCustomizeManager#setLaunchTips，如有需要请在配置文件中设置；
 iv.  废弃AIOSPhoneManager#setNumberCorrectEnabled，如有需要请联系技术支持在云端配置；
 v.   废弃AIOSPhoneManager#setIncomingBroadcastEnabled，不再提供该功能；
 vi.  废弃configs/configs.xml文件，请联系思必驰支持提供新版aios.properties文件完成相关配置；
vii.  删除aios.properties文件，新版文件请联系思必驰支持提供；

b.更新详情
1.  核验后剔除AIOSStatusListener#onPlayerStatusChange回调的IDLE状态（实际并无IDLE状态）；
2.  废弃AIOSFmListener#onSwitchChannel回调；
3.  废弃AIOSCustomizeManager#setLaunchTips，如有需要请在配置文件中设置；
4.  废弃AIOSPhoneManager#setNumberCorrectEnabled，如有需要请联系技术支持在云端配置；
5.  废弃AIOSPhoneManager#setIncomingBroadcastEnabled，不再提供该功能；
6.  废弃configs/configs.xml文件，请联系思必驰支持提供新版aios.properties文件完成相关配置；
7.  删除aios.properties文件，新版文件请联系思必驰支持提供；
8.  废弃AIOSMusicManager#postMusicSearchResult API，序号从1开始容易造成不必要的困扰，请使用AIOSMusicManager#postMusicSearchResultFromZero；
9.  废弃AIOSFmListener#onSwitchChannel 接口；
10.废弃AIOSCustomizeManager#regCommands(List<Command>,boolean)，清空操作应与注册分离；
11.废弃AIOSCustomizeManager#setLaunchTips，使用配置文件能够更好地完成该功能；
12.废弃AIOSSystemManager#stopInteractionAndRemoveUI，请使用AIOSUIManager#setUIDisappearAlways；
13.废弃AIOSTTSManager#speak(String , String )，参数集有所扩展，请见AIOSTTSManager#speak(String , int , long , int )；
14.废弃AIOSTTSManager#stopTTS(int )，参数改为long类型；
 
 ###AIOSForCarSDK - 3.2.13 release 版本更新日志
 I.   新增AIOSStatusManager#OnChatPlayerStatusListener监听器，可用于监听讲故事、笑话的状态变化。设置监听器请使用AIOSStatusManager#setOnChatPlayerStatusListener

###AIOSForCarSDK - 170405 - autolite 3.3版本更新日志
a.主要更新：
I.增加路径规划开关接口 -> AIOSMapManager#setRouteEnabled(boolean)


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 161212 - release 3.2版本更新日志
a.主要更新：
I.修改app-lib\aicommon\src\main\java\com\aispeech\aios\common\config\SDKApi  原值PLAYER_STATE = "player.state" 修改为PLAYER_STATE = "player.tts.state"


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - release 3.2版本更新日志
```
a.主要更新：
I.优化接口稳定性；
II.对注册的自定义命令进行格式验证，现在自定义命令中含有非大小写字母、数字、下划线与小数点的字符将会抛出异常；
III.新增onAIOSRebooted方法, 将重启时机通过回调的方式对外开放，您可以自行决定AIOS重启后应用的处理方式；
IV.为主动接口新增日志打印；
V.注册自定义命令从覆盖式，改为追加式。追加时出现相同说法的命令，取后加入的一条；

b.更新详情：
1.优化接口稳定性；
2.对注册的自定义命令进行格式验证，现在自定义命令中含有非大小写字母、数字、下划线与小数点的字符将会抛出异常；
3.新增onAIOSRebooted方法, 将重启时机通过回调的方式对外开放，您可以自行决定AIOS重启后应用的处理方式；
4.为主动接口新增日志打印；
5.注册自定义命令从覆盖式，改为追加式。追加时出现相同说法的命令，取后加入的一条；
6.修复若干bug
```

-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.17.161105版本更新日志
```
a.主要更新：
I.获取显示全局悬浮麦克风的状态接口 -> AIOSUIManager#getShowGlobalMic()
II.新增终止交互并移除悬浮框接口  -> AIOSSystemManager#stopInteractionAndRemoveUI()
```
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.16.161019版本更新日志
```
a.主要更新：
I.修改ACC广播(兼容原3.0广播) -> SDKBroadcast#Action#ACC
II.新增UI状态改变的通知接口  -> AIOSUIListener#onUIStateChanged(boolean)
III.新增oneshot功能，添加oneshot开关接口-> AIOSCustomizeManager#setOneshotEnabled(boolean)
IV.添加来电播报开关（内核暂不支持，未提供展示代码给客户）-> AIOSPhoneManager#setIncomingBroadcastEnabled(boolean)
V.添加语音唤醒开关 -> AIOSSystemManager#setVoiceWakeupEnabled(boolean)
VI.支持TTS优先级播报和停止播报

b.更新详情：
1.修复定制音频通道对讲笑话无效的BUG
2.新增回调前后时间戳
3.新增拼音合法性判断，非法拼音将会因为异常崩溃，此时请关注崩溃日志
4.恢复自定义命令清除功能
5.修复自定义命令失效的BUG
6.其他已知BUG
```
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.15.161014版本更新日志
```
a.主要更新：
I.主动获取唤醒状态接口 -> AIOSForCarSDK#getAIOSState()
```
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.13.160924版本更新日志
```
a.主要更新：
I.开启了打断接口，在bridge上提供了开关
```
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.12.160918版本更新日志：
```
a.主要更新：
I. 修复定制音频通道对讲笑话无效的BUG；
II. 新增拼音合法性判断，非法拼音将会因为异常崩溃，此时请关注崩溃日志；

b.更新详情：
1. 完善rebinding操作；
2. 新增sdk跟随aios-daemon重启的演示代码，您可自行定制。相关代码见aios-bridge/AndroidManifest.xml中SDKReceive接收器的注册代码；
3. 修复定制音频通道对讲笑话无效的BUG；
4. 新增拼音合法性判断，非法拼音将会因为异常崩溃，此时请关注崩溃日志；
```

-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.12.160910版本更新日志：
```
a.主要更新：
I. 废弃自定义命令的简写语法；
II. 修改UI优先级机制，现在可以设置天气、股票、限行和路况的UI忽略UI优先级直接倒计时完成后消去 -> AIOSUIManager#setUIDisappearAlways()；

b.更新详情：
1. 新增语速调节接口 -> AIOSCustomizeManager#setSpeechRate()；
2. 新增语音唤醒开关 -> AIOSSystemManager#setVoiceWakeupEnabled()；
3. AIOSSystemManager#setDaemonEnabled()现在会默认调用，参数为true。您可以在OnAIOSReadyListener中修改为false；
4. 扩大打开、关闭接口的适用范围，现在所有打开、关闭应用均可交由SDK处理（对接的应用如果已给出打开、关闭的接口，则依旧由AIOS处理）；
5. 修改UI优先级，现在可以设置天气、股票、限行和路况的UI忽略UI优先级直接倒计时完成后消去 -> AIOSUIManager#setUIDisappearAlways()；
6. 新增SDKReceive类，请参考aios-bridge的AndroidManifest.xml中代码注册该接收器：
      <receiver
            android:name="com.aispeech.aios.sdk.receiver.SDKReceiver"
            android:enabled="true"
            android:exported="true" >
            <intent-filter>
                 <action android:name="android.intent.action.BOOT_COMPLETED" />
                 <action android:name="android.intent.action.QUICKBOOT_POWERON" />

                 <!--如果需要在应用停止时被拉起来，请接收该广播-->
                 <action android:name="aios.intent.action.START_SDK_NODE"/>
            </intent-filter>
      </receiver>
7. 新增TTS反馈语定制接口 -> AIOSCustomizeManager#customizeTTSData(String)；
8. 废弃自定义命令的简写语法，存在过大的学习成本与过多的错误用法。
```
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
##AIOSForCarSDK - 1.12.160903版本更新日志：
```
a.主要更新：
I. 修复daemon崩溃之后重启，sdk不重新调用初始化接口的问题；

b.更新详情：
1. 修复daemon崩溃之后重启，sdk不重新调用初始化接口的问题；
2. 新增应用打开、关闭应用接口：AIOSSystemListener#onOpenApp(packageName) 、AIOSSystemListener#onCloseApp(packageName)
3. 删除setVolume接口；
4. 新增接口设置sdk为守护应用，设置后如果进程停止AIOS会主动拉起。请同时在广播接收器中接收“aios.intent.action.START_SDK_NODE”广播 -> AIOSSystemManager#setDaemonEnabled()
```
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.12.160827版本更新日志：
```
a.主要更新：
I. 切断sdk与aios的启动引导，aios将不再依赖sdk；
II. 去除sdk集成应用类型的区分，初始化统一使用 AIOSForCarSDK#initialize()；
III.新增自定义命令的简写语法，"[我想|我要|帮我]，可选可不选；(开了|打开)，必选其一" ，详见CustomizeActivity；

b.更新详情：
1. 切断sdk与aios的启动引导，两者将不再互相依赖；
2. 去除sdk集成应用类型的区分，初始化统一使用 AIOSForCarSDK#initialize()；
3. 剔除CustomizeParams类，请将需要在初始化时定制的参数填入AIOSForCarSDK#initialize()的回调中；
4. 自动读取assets中以下两个文件：configs/configs.xml与custom_cmd.xml，您可以在configs/configs.xml中定制领域开关、聚合开关以及默认的音量大小，也可以使用
custom_cmd.xml静态注册自定义命令；
5. 新增录音机定制接口（AEC+打断+通道反转） -> AIOSCustomizeManager#customizeRecorder()；
6. 新增定制多个主唤醒词的接口 -> AIOSCustomizeManager#setMajorWakeup(List<MajorWakeup>)；
7. 废弃setVolume接口，不再主动修改设备音量；
8. 新增搜索流程定制接口，现在可以定 制纯搜歌时是否显示结果列表（默认不显示）-> AIOSMusicManager#setDisplayListEnabled()；
9. 删除AIOSCustomizeManage#onQuickWakeUp()方法；
10. 新增自定义命令的简写语法，[我想|我要|帮我]：可选可不选；(开了|打开)：必选其一 ，详见CustomizeActivity；
```


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.10.160813版本更新日志：
```
1. 新增授权状态获取接口 -> AIOSSystemManager#isAuthSucceeded；
2. 新增AIOSCustomizeListener#onShortcutWakeUp()接口，用于替换AIOSCustomizeListener#onQuickWakeUp()，原接口依然可用但不建议继续使用；
3. 修改注释中，阈值错写为置信度的问题；
4. 修复“语音已启动”重复播报的问题；
5. 新增路况显示的起点定制接口 -> AIOSUIManager#setTrafficOrigin()；
6. 修复概率性初始化回调执行两次的问题；
7. 自定义命令新增xml文件配置的接口；
8. 新增禁用单一原生快捷唤醒词的接口 ->  AIOSCustomizeManager#disableNativeShortcutWakeup();
9. SD卡根目录新增配置文件 -> 示例配置文件请见 assert/.aios.properties文件（目前支持语音启动语、启动延时、音频通道与启动语播报延时配置）；
```


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.09.160806版本更新日志：
```
1. 优化启动流程：aios-bridge应用优先级最高，每次aios-bridge启动都将会重新aios-adapter与aios-daemon；
2. 修改应用之间的等级：aios-bridge >> aios-daemon >> aios-adapter，必须安装aios-bridge.apk或者用initializeBridge()初始化的应用（有且只能有一个，且必须能够自启动）才能启动AIOS；
3. 新增蓝牙电话、音乐与地图应用的调起广播，AIOS在应用未启动时将会发送应用调起广播并等待绑定消息发送后再publish消息；
4. 修改全部clear为clean，初期版本，不向下兼容clear方法；
5. 新增接口设置每次启动延时时间 -> CustomizeParams#delayOnBoot；
6. 新增接口设置每次启动语音播报延迟时间 -> CustomizeParams#delayOnStartupTips
7. 新增AIOS开关 -> 详见CustomizeActivity演示代码
8. 新增悬浮窗布局定制参数 -> 详见UIActivity演示代码
9. 新增收音机接口，集成调频、调幅功能 -> 详见RadioActivity演示代码
10. 新增发起、暂停与结束交互的接口 -> 详见AIOSSystemManager#startInteraction()、pauseInteraction()、stopInteraction()
11. 新增原生快捷唤醒生效开关 -> 详见AIOSCustomizeManager#setNativeShortcutWakeupsEnabled()
12. 新增音频静音与取消静音的接口，AIOS将不再提供静音功能，请实现该接口或者使用默认实现 -> AIOSAudioManager与AIOSAudioListener
```


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.08.160729版本更新日志：
```
1. 优化启动流程
2. 新增监听录音机、播放机与AIOS状态的接口
3. 新增key与授权字段
4. 新增ACC on/off与录音机 start/stop/restart接口
```


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
###AIOSForCarSDK - 1.07.160726 版本更新日志：
```
1. 修改AIOS SDK名称为AIOS for car SDK；
2. OptimizeStrategy改为SupportedRoutePlanningStrategy；
3. canOverview、canZoom 修改为setOverviewSupported、setZoomSupported ；
4. 去掉同步音乐与同步联系人的JSON接口，统一使用List接口；
5. 修改部分方法名；
6. 精简部分模块的冗余方法；
7. 修改AIOSTTSManager#speak()方法，改为播放单一文本；
8. 修改AIOSMusicManager#changePlayStatus()方法；
```
